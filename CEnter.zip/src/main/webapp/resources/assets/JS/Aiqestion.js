
const test = document.querySelector("#test")
const aian = document.querySelector("#aian")
const anOX = document.querySelector("#anOX")
const savebtn = document.querySelector(".savebtn")
const useranswer = document.querySelector("#useranswer")
let qn = "";
let yn = "";
let er = "";

function search() {
  const api_key = "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"
  console.log(api_key);
  const keywords = document.getElementById('keywords').dataset.question
  console.log(keywords);
  const messages = [
    { role: 'system', content: 'You are a helpful assistant.' },
    { role: 'user', content: keywords + '에 대한 문제를 만들어줄수 있을까?? 문제는 한문제 만들어 주면 되고 네 알겠습니다 이런 답변 없이 그냥 바로 문제 만들어주라 무조건 코딩 문제만 작성해줘 문제는 빈칸 문제로 해주고 문제에 대한 결과값이 어떻게 나오는지 결과 값만 작성해줘 답이 아니라 결과값을 작성해야 한다' },
  ]
  const config = {
    headers: {
      Authorization: `Bearer ${api_key}`,
      'Content-Type': 'application/json',
    },
  }
  const data = {
    model: 'gpt-4',
    temperature: 0.5,
    n: 1,
    messages: messages,
  }
  axios
    .post('https://api.openai.com/v1/chat/completions', data, config)
    .then(function (response) {
      let resultDiv = document.getElementById('result')
      resultDiv.innerHTML = ''

      // 모든 내용 불러오기
      response.data.choices.forEach(function (choice, index) {
        resultDiv.innerHTML += choice.message.content
          .replace(/[`]/g, '') // 백틱 제거
          .split('\n') // 줄 바꿈 기준으로 분리
          //.map(line => `<div>${line}</div>`) // 각 줄을 <div>로 감쌈
          .map(line => {
            // <div> 태그를 문자열로 감쌈
            return `<div>${line.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</div>`;
          })
          .join(''); // 모든 <div>를 하나의 문자열로 합침
      });

      qn = resultDiv.textContent;

      fetch('http://localhost:8082/controller/api', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ result: qn }), // JSON 형태로 데이터 전송
      })
        .then(response => {
          // JSON 응답인지 확인
          const contentType = response.headers.get("content-type");
          if (!contentType || !contentType.includes("application/json")) {
            throw new Error("서버에서 JSON이 아닌 데이터를 반환했습니다!");
          }
          return response.json();
        })
        .then(data => {
          console.log('서버 응답:', data);
        })
    })
    .catch(function (error) {
      console.error(error)
    })
}


function answer(qn) {
  const api_key = "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"
  const messages = [
    { role: 'system', content: 'You are a helpful assistant.' },
    { role: 'user', content: qn + '이 문제 정답알려주지 말고 힌트 주라' },
  ]
  const config = {
    headers: {
      Authorization: `Bearer ${api_key}`,
      'Content-Type': 'application/json',
    },
  }
  const data = {
    model: 'gpt-4',
    temperature: 0.5,
    n: 1,
    messages: messages,
  }
  axios
    .post('https://api.openai.com/v1/chat/completions', data, config)
    .then(function (response) {
      let resultDiv = document.getElementById('answer')
      resultDiv.innerHTML = ''
      response.data.choices.forEach(function (choice, index) {
        resultDiv.innerHTML += choice.message.content
          .replace(/[`]/g, '') // 백틱 제거
          .split('\n') // 줄 바꿈 기준으로 분리
          //.map(line => `<div>${line}</div>`) // 각 줄을 <div>로 감쌈
          .map(line => {
            // <div> 태그를 문자열로 감쌈
            return `<div>${line.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</div>`;
          })
          .join(''); // 모든 <div>를 하나의 문자열로 합침
      });
    })
    .catch(function (error) {
      console.error(error)
    })
}


function OX(qn) {
  er = useranswer.value;
  const api_key = "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"
  const messages = [
    { role: 'system', content: 'You are a helpful assistant.' },
    { role: 'user', content: qn + "<<<<<이 코딩 문제의 빈칸에 들어갈 정답이>>>>>" + er + "<<<<<이게 맞으면 O 틀리면 X 라고 답해 확실하게 맞았을 떄 정답이라고 해줘 오타도 틀렸다고 해야 돼 무조건 O랑 X로만 답해야 돼. 같이보낸 결과값은 보지말고 내가 답한 내용만 보고 대답해" },
  ]
  const config = {
    headers: {
      Authorization: `Bearer ${api_key}`,
      'Content-Type': 'application/json',
    },
  }
  const data = {
    model: 'gpt-4',
    temperature: 0,
    n: 1,
    messages: messages,
  }
  axios
    .post('https://api.openai.com/v1/chat/completions', data, config)
    .then(function (response) {
      response.data.choices.forEach(function (choice, index) {
        yn = choice.message.content
          .replace(/[`]/g, '') 
          .split('\n') 
          .map(line => {
            return `${line.replace(/</g, "&lt;").replace(/>/g, "&gt;")}`;
          })
          .join(''); 
        if(yn != "O"){
          yn = "X"
          alert("오답")
        }else{
           alert("정답")
        }
        

      });
      
      

      fetch('http://localhost:8082/controller/api', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ result: qn, ynresult: yn, usersresult: er }), // JSON 형태로 데이터 전송
      })
        .then(response => {
          // JSON 응답인지 확인
          const contentType = response.headers.get("content-type");
          if (!contentType || !contentType.includes("application/json")) {
            throw new Error("서버에서 JSON이 아닌 데이터를 반환했습니다!");
          }
          return response.json();
        })
        .then(data => {
          console.log('서버 응답:', data);
        })
    })
    .catch(function (error) {
      console.error(error)
    })
}


anOX.addEventListener("click", () => {
  OX(qn)
})


aian.addEventListener("click", () => {
  answer(qn)
})

test.addEventListener("click", search)

