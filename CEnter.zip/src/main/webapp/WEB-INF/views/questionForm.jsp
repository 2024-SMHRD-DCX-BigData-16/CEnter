<%@ page contentType="text/html;charset=UTF-8" language="java"%>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<title>질문 입력</title>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<link rel="stylesheet"
	href="resources/assets/css/questionform.css?v=1.0">
</head>
<body>
	<div class="con">

		<!-- header -->
		<div class="header">
			<h3>
				C<span class="blue">E</span>nter
			</h3>
			<div class="nav">
				<ul>
					<li><a href="/controller">Home</a></li>
					<li><a href="goQuestionMain">Class</a></li>
					<li><a href="postselect">Community</a></li>
					<c:if test="${empty loggedInUser}">
						<li><button class="login">Sign</button></li>
					</c:if>
					<c:if test="${not empty loggedInUser}">
						<li><a href="logout">Logout</a></li>
					</c:if>
				</ul>
			</div>
		</div>
		<!-- main -->
		<div class="inner">
			<div class="main">
				<div class="top">
					<div class="categori">
						<ul>
							<c:forEach var="to" items="${topic}">
								<c:out value="${to}" escapeXml="false" />
							</c:forEach>
						</ul>
					</div>
					<div class="detailtext">
						<c:out value="${catopics}" escapeXml="false" />
					</div>
				</div>
				<div class="buttom">
					<c:if test="${param.lang ne 'codingstart'}">
						<div class="aileft">
							<div class="ex">
								<a href="javascript:void(0)" id="test">예제보기</a> 
								<a href="javascript:void(0)" id="aian">ai 힌트</a>
							</div>
							<div class="aiitem">
								<div id="result"></div>
								<div id="answer"></div>
							</div>
						</div>
						<div class="airight">
							<div class="ex">
								<a href="javascript:void(0)" id="anOX">결과</a>
							</div>
							<form action="questionanswer" method="post">
								<textarea rows="" cols="" id="useranswer"></textarea>
								<input type="hidden" value="${param.lang}" name="lang">
								<input type="hidden" value="${param.ca}" name="ca"> <input
									type="submit" value="저장하기" class="savebtn">
							</form>
						</div>


					</c:if>
				</div>
			</div>
		</div>

	</div>



	<div id="keywords" data-question="${param.ca}"></div>
	<a href="/controller/goquestionForm?lang=${param.lang}&ca=${pram.ca}"
		class="hiddenbtn"></a>



	<script
		src="${pageContext.request.contextPath}/resources/assets/JS/Aiqestion.js"></script>
	<!-- <script type="text/javascript">
		const save = document.querySelector(".save")
		const hiddenbtn = document.querySelector(".hiddenbtn")
		
        save.addEventListener("click" ,() => {
            hiddenbtn.click()
        })
		
	</script> -->
</body>
</html>
