<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form"%>

<!DOCTYPE html>
<html lang="ko">
<head>
<title>Forty by HTML5 UP</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet"
	href="resources/assets/css/questionmain.css?v=1.0">
<title>Insert title here</title>
</head>
<body>
	<div class="con">
		<div class="header">
			<h3>
				C<span class="blue">E</span>nter
			</h3>
			<div class="nav">
				<ul>
					<li><a href="/controller">Home</a></li>
					<li><a href="goQuestionMain">Class</a></li>
					<li><a href="postselect">Community</a></li>
					<c:if test="${empty loggedInUser}">
						<li><button class="login">Sign</button></li>
					</c:if>
					<c:if test="${not empty loggedInUser}">
						<li><a href="logout">Logout</a></li>
					</c:if>
				</ul>
			</div>
		</div>

		<div class="codingbox">
			<div class="itembox_a">
				<div class="item">
					<p>코딩 기초</p>
					<div class="img" style="background-image: url(resources/images/start.gif)"></div>
					<ul>
						<li><a href="goquestionForm?lang=codingstart">코딩이야기</a></li>
						<li><a href="goquestionForm?lang=html">HTML</a></li>
						<li><a href="goquestionForm?lang=css">CSS</a></li>
					</ul>
				</div>
				<div class="item">
					<p>프로그래밍 언어</p>
					<div class="img" style="background-image: url(resources/images/coding.gif)"></div>
					<ul>
						<li><a href="goquestionForm?lang=javascript">JavaScript</a></li>
						<li><a href="goquestionForm?lang=php">PHP</a></li>
						<li><a href="goquestionForm?lang=python">Python</a></li>
						<li><a href="goquestionForm?lang=java">Java</a></li>
						<li><a href="goquestionForm?lang=c">C언어</a></li>
					</ul>
				</div>
				<div class="item">
					<p>기술 스택</p>
					<div class="img" style="background-image: url(resources/images/stack.gif)"></div>
					<ul>
						<li><a href="goquestionForm?lang=react">React</a></li>
						<li><a href="goquestionForm?lang=jquery">jQuery</a></li>
					</ul>
				</div>
			</div>
			<div class="itembox_b">
				<div class="item">
					<p>데이터베이스</p>
					<div class="img" style="background-image: url(resources/images/database.gif)"></div>
					<ul>
						<li><a href="goquestionForm?lang=mysql">MySQL</a></li>
					</ul>
				</div>
				<div class="item">
					<p>XML 관련</p>
					<div class="img" style="background-image: url(resources/images/xml.gif)"></div>
					<ul>
						<li><a href="goquestionForm?lang=xml">XML</a></li>
					</ul>
				</div>
			</div>
		</div>

	</div>


</body>
</html>