<%@ page contentType="text/html;charset=UTF-8" language="java"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<title>질문 목록</title>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<link rel="stylesheet"
	href="resources/assets/css/questonread.css?v=1.0">
</head>
<body>

	<div class="con">
		<div class="header"
			style="background-image: url(resources/images/rock.png)">
			<h3>
				C<span class="blue">E</span>nter
			</h3>
			<div class="nav">
				<ul>
					<li><a href="/controller">Home</a></li>
					<li><a href="goQuestionMain">Class</a></li>
					<li><a href="postselect">Community</a></li>
					<c:if test="${empty loggedInUser}">
						<li><button class="login">Sign</button></li>
					</c:if>
					<c:if test="${not empty loggedInUser}">
						<li><a href="logout">Logout</a></li>
					</c:if>
				</ul>
			</div>
		</div>
		<div class="inner">
			<div class="main">
				<div class="left">
					<p>문제</p>
					<div class="itembox">${answerdone.ans_problem}</div>
				</div>
				<div class="right">
					<p>정답</p>
					<div class="itembox">${answerdone.user_answer}</div>
				</div>
			</div>
		</div>
	</div>

</body>
</html>
