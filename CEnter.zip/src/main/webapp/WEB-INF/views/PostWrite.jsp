<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Forty by HTML5 UP</title>
<meta charset="utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="resources/assets/css/postwrite.css?v=1.0">
</head>
<body>
	<div class="con">
		<!-- header -->
		<div class="header" style="background-image: url(resources/images/postbm.jpg)">
			<h3>
				C<span class="blue">E</span>nter
			</h3>
			<div class="nav">
				<ul>
					<li><a href="/controller">Home</a></li>
					<li><a href="goQuestionMain">Class</a></li>
					<li><a href="postselect">Community</a></li>
					<c:if test="${empty loggedInUser}">
						<li><button class="login">Sign</button></li>
					</c:if>
					<c:if test="${not empty loggedInUser}">
						<li><a href="logout">Logout</a></li>
					</c:if>
				</ul>
			</div>
		</div>

		<!-- nav -->
		<div class="postcon">
			<div class="inner">
				<div class="leftitem">
					<div class="comubox">
						<ul>
							<li><a href="postselect">전체보기</a></li>
							<li><a href="?category=공지사항">공지사항</a></li>
							<li><a href="?category=요청사항">요청사항</a></li>
							<li><a href="?category=파일공유">파일공유</a></li>
							<li><a href="?category=QnA">QnA</a></li>
							<li><a href="?category=자유게시판">자유게시판</a></li>
						</ul>
					</div>
				</div>
			<div class="rightitem">
				<form class="itembox" action="postinsert" method="post" enctype="multipart/form-data">
					<div class="input-group">
						<input type="text" placeholder="제목" name="post_title"> <input
							type="text" placeholder="작성자" name="mb_id"
							value="${loggedInUser.mb_id}">
					</div>
					<div class="input-group">
						<input class="file-btn" type="file" name="post_file"> <select
							name="post_category">
							<c:if test="${loggedInUser.mb_id eq 'admin'}">
								<option>공지사항</option>
							</c:if>
							<option>요청사항</option>
							<option>파일공유</option>
							<option>자유게시판</option>
							<option>QnA</option>
						</select>
					</div>
					<textarea class="content-box" placeholder="내용을 입력하세요"
						name="post_content"></textarea>
					<div class="button-group">
						<input class="reset" type="reset"> <input class="submit"
							type="submit">
					</div>
				</form>
			</div>
			</div>
		</div>
		<!-- 게시판 -->

	</div>
</body>

</html>