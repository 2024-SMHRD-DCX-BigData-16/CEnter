<%@ page language="java" contentType="text/html; charset=UTF-8"
   pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form"%>

<!DOCTYPE html>
<html lang="ko">
<head>
<title>Forty by HTML5 UP</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="resources/assets/css/main.css?v=1.0">
<link rel="stylesheet"
   href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
   integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
   crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
   <!-- main소개 1 -->
   <div class="con"
      style="background-image: url(resources/images/background.gif)">
      <div class="header">
         <h3>
            C<span class="blue">E</span>nter
         </h3>
         <div class="nav">
            <ul>
               <li><a href="/controller">Home</a></li>
               <li><a href="goQuestionMain">Class</a></li>
               <li><a href="postselect">Community</a></li>
               <c:if test="${empty loggedInUser}">
                  <li><button class="login">Sign</button></li>
               </c:if>
               <c:if test="${not empty loggedInUser}">
                  <li class="userid">
                  <a href="#">${loggedInUser.mb_name}</a>
                  <ul class="usermodal">
                     <li><button class="updatebtn">회원정보수정</button></li>
                     <li><a href="answerselect">예제목록보기</a></li>
                  </ul>
                  </li>
                  
                  <li><a href="logout">Logout</a></li>
               </c:if>
            </ul>
         </div>
      </div>
      <div class="text">
         <p>IT전문가를 위한 첫걸음</p>
         <p>
            지금, <span class="taiping">C<span>E</span>nter에서
            </span>
         </p>
         <p>
            C<span class="blue">E</span>nter에서
         </p>
      </div>
   </div>

   <!-- main 소개 2 -->
   <div class="box">
      <div class="text">
         <h3>어떤 학습을 제공하나요?</h3>
      </div>
      <div class="box-item">
         <div class="item">
            <div class="java"
               style="background-image: url(resources/images/자바.png);"></div>
            <h4>java</h4>
         </div>
         <div class="item">
            <div class="python"
               style="background-image: url(resources/images/파이썬.png);"></div>
            <h4>python</h4>
         </div>
         <div class="item">
            <div class="c"
               style="background-image: url(resources/images/c언어.png);"></div>
            <h4>c언어</h4>
         </div>
         <div class="item">
            <div class="js"
               style="background-image: url(resources/images/자바스크립트.png);"></div>
            <h4>javaScript</h4>
         </div>
         <div class="item">
            <div class="react"
               style="background-image: url(resources/images/react.png);"></div>
            <h4>react</h4>
         </div>
         <div class="item">
            <div class="spring"
               style="background-image: url(resources/images/스프링.png);"></div>
            <h4>spring</h4>
         </div>
         <div class="item">
            <div class="js"
               style="background-image: url(resources/images/자바스크립트.png);"></div>
            <h4>javaScript</h4>
         </div>
      </div>
      <div class="buttons">
         <span class="prev"></span> <span class="next"></span>
      </div>
   </div>
   <!-- main소개 3 -->
  <div class="leg">
    <div class="text">
      <h3 class="qnaContent">
        <p>어떤 학습을 제공하나요?</p>
      </h3>
      <div class="mainContent">
        <p> C<span class="blue">E</span>nter는</p>
        <p>IT 분야의 기반을 다질 수 있는</p>
        <p>학습기회를 제공합니다!</p>
      </div>
      <div class="reContent">
         <p>경제적, 사회적 배경에 상관없이</p>
         <p>누구나 잠재력을 펼칠 수 있는 사회를 만들어 갑니다.</p>
      </div>
    </div>
    <div class="languIntro">
      <span style="--i:1;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:2;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:3;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:4;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:5;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:6;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:7;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:8;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:9;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:10;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:11;"><i class="fa-solid fa-moon"></i></span>
      <span style="--i:12;"><i class="fa-solid fa-moon"></i></span>
    </div>
  </div>

   <div class="qna-section">
      <h2>저도 할 수 있을까요?</h2>
      <div class="qna-container">
         <div class="qna-pair">
            <div class="qna qna-left">
               <p class="question">Q. 제 실력을 잘 모르겠어요..</p>
            </div>
            <div class="qna qna-right">
               <p class="answer">AI가 수준에 맞게 알려줄거에요!</p>
            </div>
         </div>

         <div class="qna-pair">
            <div class="qna qna-left">
               <p class="question">Q. 비전공자도 할 수 있을까요?</p>
            </div>
            <div class="qna qna-right">
               <p class="answer">기초부터 차근차근 알려줘서 충분히 가능해요!</p>
            </div>
         </div>

         <div class="qna-pair">
            <div class="qna qna-left">
               <p class="question">Q. 미성년자도 들을 수 있나요?</p>
            </div>
            <div class="qna qna-right">
               <p class="answer">그럼요! 듬직한 AI가 이해하기 쉽게 도와줘요!</p>
            </div>
         </div>

         <div class="qna-pair">
            <div class="qna qna-left">
               <p class="question">Q. 취업에 도움이 될까요?</p>
            </div>
            <div class="qna qna-right">
               <p class="answer">코딩 레벨을 꾸준히 높여 취뽀까지 가능해요!</p>
            </div>
         </div>
      </div>
   </div>

   <!-- main소개 5-->
   <div class="different-section">
      <h2>
         왜 C<span class="blue">E</span>nter는 다른가?
      </h2>
      <div class="different-grid">
         <div class="different-item">
            <h3>기초부터 심화까지!</h3>
            <p>
               수강생의 레벨에 맞게 진행하는<br>AI 학습지도 코딩!
            </p>
         </div>
         <div class="different-item">
            <h3>카테고리 별 학습 진행!</h3>
            <p>
               원하는 강의를 언제 어디서나<br>듣고 학습 할 수 있는 시스템!
            </p>
         </div>
         <div class="different-item">
            <h3>개발도구 및 툴 사용법!</h3>
            <p>
               수강생의 니즈를 충족할 수 있도록<br>필요한 강의만 쏙쏙!
            </p>
         </div>
         <div class="different-item">
            <h3>Only Online!</h3>
            <p>
               오프라인과 달리<br>당당하게 활동가능한 온라인 사이트!
            </p>
         </div>
      </div>
   </div>

   <!-- main 6 -->
   <div class="inspiration">
      <div class="inspiration-section">
         <h3>
            "0과 1이 만들어내는 <span class="blue">무한한</span> 가능성,
         </h3>
         <h3>
            당신의 코드로 세상의 <span class="blue">중심</span>으로 향하여!"
         </h3>
      </div>
      <div class="inspiration-text">
         <h3>
            "코딩은 <span class="blue">세상</span>을 바라보는 또 다른 <span class="blue">시각</span>입니다.
         </h3>
         <h3>
            당신만의 <span class="blue">시각</span>을 만들어보세요!"
         </h3>
      </div>
      <h2>
         여기 C<span class="blue">E</span>nter에서 시작!
      </h2>
   </div>

   <!-- 로그인 창 -->
   <div class="bulbackgro">
      <div class="login">
         <h2>Login</h2>
         <form action="memberLogin" method="post">
            <input type="text" placeholder="Id" name="mb_id" class="logininp">
            <input type="password" placeholder="Password" name="mb_pw"
               class="logininp"> <input type="submit" value="Login"
               class="loginsub">
         </form>
         <p>
            비밀번호를 잊으셨나요?<a href="#">비밀번호 찾기</a>
         </p>
         <p>
            계정이 없나요?
            <button class="sign_up">회원가입</button>
         </p>
      </div>
      <div class="join">
         <h2>Sign up</h2>
         <form action="memberInsert" method="post">
            <input type="text" placeholder="Id" name="mb_id" class="logininp">
            <input type="password" placeholder="Password" name="mb_pw"
               class="logininp"> <input type="text" placeholder="Name"
               name="mb_name" class="logininp"> <input type="submit"
               value="Sign up" class="loginsub">
         </form>
      </div>
   </div>
   
   <div class="updateback">
      <div class="update">
         <h2>Update</h2>
         <form action="updateMember" method="post">
            <input type="password" placeholder="Password" name="mb_pw" class="updatepw">
            <input type="text" placeholder="name" name="mb_name" class="updatename"> 
            <input type="submit" value="Update" class="updatesub">
         </form>
      </div>
   </div>

   <div id="userInfo" data-loginmessage="${loginmessage}"></div>

   <script>
    // main 2 학습 앞 뒤 버튼
    const prev = document.querySelector('.prev')
    const next = document.querySelector('.next')

    next.addEventListener('click', () =>{
      let items = document.querySelectorAll('.item')
      document.querySelector('.box-item').appendChild(items[0])
    })
    prev.addEventListener('click', () =>{
      let items = document.querySelectorAll('.item')
      document.querySelector('.box-item').prepend(items[items.length-1])
    })

    // 로그인 블러 처리
    const loginbackgro = document.querySelector(".bulbackgro")
    const loginbox = document.querySelector(".bulbackgro .login")
    const joinbox = document.querySelector(".bulbackgro .join")
    const loginbtn = document.querySelector("button.login")
    const body = document.querySelector("body")
   const navUl = document.querySelector(".con .nav ul")

    loginbtn.addEventListener('click', () => {
      body.style.overflow = 'hidden'
      body.style.paddingRight = '17px'
      navUl.style.display = 'none'
      loginbackgro.style.display = 'flex'
      loginbackgro.classList.add('bulr')
      loginbox.style.transform = 'perspective(800px) rotateY(0deg)'
      joinbox.style.transform = 'perspective(800px) rotateY(180deg)'
    })
    loginbackgro.addEventListener('click', () =>{
      body.style.overflow = 'auto'
      body.style.paddingRight = '0px'
      loginbackgro.style.display = 'none'
      navUl.style.display = 'flex'
      loginbackgro.classList.remove('bulr')
      loginbox.style.transform = 'perspective(800px) rotateY(0deg)'
      joinbox.style.transform = 'perspective(800px) rotateY(180deg)'
    })

    loginbox.addEventListener('click', e =>{
      e.stopPropagation()
    })
    joinbox.addEventListener('click', e =>{
      e.stopPropagation()
    })

    //로그인 에서 회원가입 전환
    const sign_up = document.querySelector(".bulbackgro .login p .sign_up")

    sign_up.addEventListener('click', ()=>{
      loginbox.style.transform = 'perspective(800px) rotateY(180deg)'
      joinbox.style.transform = 'perspective(800px) rotateY(360deg)'
    })
    
    const loginmessage = document.getElementById("userInfo").getAttribute("data-loginmessage");
    if(loginmessage != ""){
       alert(loginmessage)   
    }

    

  </script>
  
  <!-- 회원 정보 -->
  <script>
     /* 모달창 */
     const userid = document.querySelector(".userid")
     const usermodal = document.querySelector(".usermodal")
     if(userid){
        userid.addEventListener("mouseover", ()=>{
           usermodal.style.opacity = "1";
           usermodal.style.visibility = "visible";
        })
        userid.addEventListener("mouseout", ()=>{
           usermodal.style.opacity = "0";
           usermodal.style.visibility = "hidden";
        })
     }
     /* 회원 정보 */
     const upbackgro = document.querySelector(".updateback")
     const upbox = document.querySelector(".updateback .update")
   const upbtn = document.querySelector("button.updatebtn")
   
   upbtn.addEventListener('click', () => {
     body.style.overflow = 'hidden'
     body.style.paddingRight = '17px'
     navUl.style.display = 'none'
     upbackgro.style.display = 'flex'
     upbackgro.classList.add('bulr')
   })
   upbackgro.addEventListener('click', () =>{
     body.style.overflow = 'auto'
     body.style.paddingRight = '0px'
     upbackgro.style.display = 'none'
     navUl.style.display = 'flex'
     upbackgro.classList.remove('bulr')
   })
   
   upbox.addEventListener('click', e =>{
     e.stopPropagation()
   })
     
  </script>
  
  <!-- 애니메이션 -->
  <script type="text/javascript">
  /* main1 */
  const item1 = document.querySelector(".box h3")
  const item2 = document.querySelector(".box-item")
  const item3 = document.querySelector(".buttons")

  let observer1 = new IntersectionObserver(e => {
      e.forEach((en)=>{
       if(en.isIntersecting){
            en.target.style.opacity = 1;        
       }else{
            en.target.style.opacity = 0;                  
       } 
      })
  })
  let observer2 = new IntersectionObserver(e => {
      e.forEach((en)=>{
       if(en.isIntersecting){
            en.target.style.opacity = 1;        
            en.target.style.transform = "translateY(0px)";        
       }else{
            en.target.style.opacity = 0;  
            en.target.style.transform = "translateY(100px)"; 
       } 
      })
  })
  
  let observer3 = new IntersectionObserver(e => {
      e.forEach((en)=>{
       if(en.isIntersecting){
            en.target.style.opacity = 1;        
            en.target.style.transform = "translateY(0px)";
            en.target.style.transition = "all 1s .2s"; 
       }else{
            en.target.style.opacity = 0;  
            en.target.style.transform = "translateY(100px)"; 
            en.target.style.transition = "all 1s"; 
       } 
      })
  })


  observer1.observe(item1)
  observer2.observe(item2)
  observer3.observe(item3)
  
  /* main2 */
  const item4 = document.querySelector(".qnaContent")
   const item5 = document.querySelector(".mainContent")
   const item6 = document.querySelector(".reContent")
   
   let observer4 = new IntersectionObserver(e => {
       e.forEach((en)=>{
         if(en.isIntersecting){
               en.target.style.opacity = 1;        
               en.target.style.transform = "translateX(0px)";        
         }else{
               en.target.style.opacity = 0;  
               en.target.style.transform = "translateX(-100px)"; 
         } 
       })
   })
   let observer5 = new IntersectionObserver(e => {
       e.forEach((en)=>{
         if(en.isIntersecting){
               en.target.style.opacity = 1;        
               en.target.style.transform = "translateX(0px)";  
               en.target.style.transition = "all 1s .2s"; 
         }else{
               en.target.style.opacity = 0;  
               en.target.style.transform = "translateX(-100px)"; 
               en.target.style.transition = "all 1s"; 
         } 
       })
   })
   let observer6 = new IntersectionObserver(e => {
       e.forEach((en)=>{
         if(en.isIntersecting){
               en.target.style.opacity = 1;        
               en.target.style.transform = "translateX(0px)";  
               en.target.style.transition = "all 1s .4s"; 
         }else{
               en.target.style.opacity = 0;  
               en.target.style.transform = "translateX(-100px)"; 
               en.target.style.transition = "all 1s"; 
         } 
       })
   })
   
   
   observer4.observe(item4)
    observer5.observe(item5)
    observer6.observe(item6)

    /* main3 */
    const item8 = document.querySelectorAll(".qna.qna-left")
    const item9 = document.querySelectorAll(".qna.qna-right")

   let observer8 = new IntersectionObserver(e => {
       e.forEach((en)=>{
         if(en.isIntersecting){
               en.target.style.opacity = 1;        
               en.target.style.transform = "translateX(0px)";        
         }else{
               en.target.style.opacity = 0;  
               en.target.style.transform = "translateX(-100px)"; 
         } 
       })
   })
   let observer9 = new IntersectionObserver(e => {
       e.forEach((en)=>{
         if(en.isIntersecting){
               en.target.style.opacity = 1;        
               en.target.style.transform = "translateX(0px)";        
         }else{
               en.target.style.opacity = 0;  
               en.target.style.transform = "translateX(100px)"; 
         } 
       })
   })
   
   
   item8.forEach(e=>{
       observer8.observe(e)
   })
   item9.forEach(e=>{
       observer9.observe(e)
   })


  
  
  </script>
</body>
</html>