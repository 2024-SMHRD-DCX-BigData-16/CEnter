<%@page import="com.center.entity.Post"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form"%>

<!DOCTYPE html>
<html lang="ko">
<head>
<title>Forty by HTML5 UP</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="resources/assets/css/postmain.css?v=1.0">
<script>
	window.addEventListener("pageshow", function(event) {
		if (event.persisted) {
			location.reload(); // 뒤로 가기 시 강제 새로고침
		}
	});
</script>
</head>
<body>
	<div class="con">
		<!-- header -->
		<div class="header" style="background-image: url(resources/images/postbm.jpg)">
			<h3>
				C<span class="blue">E</span>nter
			</h3>
			<div class="nav">
				<ul>
					<li><a href="/controller">Home</a></li>
					<li><a href="goQuestionMain">Class</a></li>
					<li><a href="postselect">Community</a></li>
					<c:if test="${empty loggedInUser}">
						<li><button class="login">Sign</button></li>
					</c:if>
					<c:if test="${not empty loggedInUser}">
						<li><a href="logout">Logout</a></li>
					</c:if>
				</ul>
			</div>
		</div>

		<!-- nav -->
		<div class="postcon">
			<div class="inner">
				<div class="leftitem">
					<div class="comubox">
						<ul>
							<li><a href="postselect">전체보기</a></li>
							<li><a href="?category=공지사항">공지사항</a></li>
							<li><a href="?category=요청사항">요청사항</a></li>
							<li><a href="?category=파일공유">파일공유</a></li>
							<li><a href="?category=QnA">QnA</a></li>
							<li><a href="?category=자유게시판">자유게시판</a></li>
						</ul>
						<div class="write"><a href="postwrite">작성</a></div>
					</div>
				</div>
				<div class="rightitem">
					<div class="itembox">
						<ul>
							<li class="title">
								<p>제목</p>
								<p>작성자</p>
								<p>날짜</p>
								<p>조회수</p>
								<p>좋아요</p>
							</li>
							<%
							String pageParam = request.getParameter("page");
							String categoryParam = request.getParameter("category");
							int num = (pageParam != null) ? Integer.parseInt(pageParam) : 0;
							String category = (categoryParam != null) ? "category=" + categoryParam + "&" : "";
							List<Post[]> chunkedList = (List<Post[]>) request.getAttribute("chunkedList");
							%>
							<%
							for (Post post : chunkedList.get(num)) {
							%>
							<li><a href="postcontent?idx=<%=post.getPost_idx()%>"
								style="cursor: pointer;"><%=post.getPost_title()%></a>
								<div><%=post.getMb_id()%></div>
								<div><%=post.getCreated_at()%></div>
								<div><%=post.getPost_views()%></div>
								<div><%=post.getPost_likes()%></div>
							</li>
							<%
							}
							%>
						</ul>
						<div class="listnum">
							<%
							for (int i = 0; i < chunkedList.size(); i++) {
							%>
							<div>
								<a href="?<%=category%>page=<%=i%>"><%=i%></a>
							</div>
							<%
							}
							%>
						</div>
					</div>
				</div>
			</div>
			
		</div>
		<!-- 게시판 -->
	</div>


</body>
</html>