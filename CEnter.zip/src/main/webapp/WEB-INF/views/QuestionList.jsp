<%@page import="com.center.entity.Answer"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form"%>

<!DOCTYPE html>
<html lang="ko">
<head>
<title>Forty by HTML5 UP</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
<link rel="stylesheet"
	href="resources/assets/css/questionlist.css?v=1.0">
</head>
<body>
	<div class="con">
		<div class="header"
			style="background-image: url(resources/images/rock.png)">
			<h3>
				C<span class="blue">E</span>nter
			</h3>
			<div class="nav">
				<ul>
					<li><a href="/controller">Home</a></li>
					<li><a href="goQuestionMain">Class</a></li>
					<li><a href="postselect">Community</a></li>
					<c:if test="${empty loggedInUser}">
						<li><button class="login">Sign</button></li>
					</c:if>
					<c:if test="${not empty loggedInUser}">
						<li><a href="logout">Logout</a></li>
					</c:if>
				</ul>
			</div>
		</div>

		<div class="postcon">
			<div class="inner">
				<div class="leftitem">
					<div class="comubox">
						<ul>
							<li><a href="answerselect">전체보기</a></li>
							<li><a href="?category=HTML">HTML</a></li>
							<li><a href="?category=CSS">CSS</a></li>
							<li><a href="?category=JavaScript">JavaScript</a></li>
							<li><a href="?category=PHP">PHP</a></li>
							<li><a href="?category=Python">Python</a></li>
							<li><a href="?category=Java">Java</a></li>
							<li><a href="?category=C언어">C언어</a></li>
							<li><a href="?category=react">react</a></li>
							<li><a href="?category=jQuery">jQuery</a></li>
							<li><a href="?category=MySQL">MySQL</a></li>
							<li><a href="?category=XML">XML</a></li>
						</ul>
					</div>
				</div>

				<div class="rightitem">
					<div class="itembox">
						<ul>
							<li class="title">
								<p>아이디</p>
								<p>아이템</p>
								<p>결과</p>
								<p>작성일</p>
							</li>


							<%
							String pageParam = request.getParameter("page");
							String categoryParam = request.getParameter("category");
							int num = (pageParam != null) ? Integer.parseInt(pageParam) : 0;
							String category = (categoryParam != null) ? "category=" + categoryParam + "&" : "";
							List<Answer[]> answercheck = (List<Answer[]>) request.getAttribute("answercheck");
							%>
							<%
							for (Answer answer : answercheck.get(num)) {
							%>
							<li><a href="questioncontent?idx=<%=answer.getAns_idx()%>"
								style="cursor: pointer;"><%=answer.getMb_id()%></a>
								<div><%=answer.getAns_item()%></div>
								<div><%=answer.getAns_yn()%></div>
								<div><%=answer.getCreated_at()%></div></li>
							<%
							}
							%>
						</ul>
						<div class="listnum">
							<%
							for (int i = 0; i < answercheck.size(); i++) {
							%>
							<div>
								<a href="?<%=category%>page=<%=i%>"><%=i%></a>
							</div>
							<%
							}
							%>


						</div>
					</div>
				</div>
			</div>
		</div>
</body>
</html>