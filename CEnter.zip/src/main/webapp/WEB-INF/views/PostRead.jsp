<%@ page language="java" contentType="text/html; charset=EUC-KR"
	pageEncoding="EUC-KR"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="EUC-KR">
<title>Insert title here</title>
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
	integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg=="
	crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="resources/assets/css/postread.css?v=1.0">
</head>
<body>
	<div class="con">
		<!-- header -->
		<div class="header"
			style="background-image: url(resources/images/postbm.jpg)">
			<h3>
				C<span class="blue">E</span>nter
			</h3>
			<div class="nav">
				<ul>
					<li><a href="/controller">Home</a></li>
					<li><a href="goQuestionMain">Class</a></li>
					<li><a href="postselect">Community</a></li>
					<c:if test="${empty loggedInUser}">
						<li><button class="login">Sign</button></li>
					</c:if>
					<c:if test="${not empty loggedInUser}">
						<li><a href="logout">Logout</a></li>
					</c:if>
				</ul>
			</div>
		</div>
		<div class="inner">
			<div class="main">
				<div class="header">
					<div class="title">
						<h1>${postdone.post_title}</h1>
					</div>
					<div class="detali">
						<div class="userimpo">
							<div>${postdone.mb_id}</div>
							<div>${postdone.created_at}</div>
						</div>
						<div class="share">
							<a href="#">URL ����</a>
						</div>
					</div>
				</div>
				<div class="contentbox">
					<div>
						<img alt="${postdone.post_file}"
							src="./resources/upload/${postdone.post_file}">
					</div>
					<p>${postdone.post_content}</p>
				</div>
			</div>
			<div class="bottominner">
				<div class="bottombox">
					<div class="like">
						<i class="fa-regular fa-heart"></i>
						<p>���� ${postdone.post_likes}</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>