package com.center.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.center.entity.Post;

@Mapper
public interface PostMapper {

	public void postInsert(Post post);

	public List<Post> postselect();

	public Post postcontent(int idx);

	public List<Post> getPostsByCategory(String category);
	
	public void updateViewCount(int idx);

	public int insertPost(Post post);
}