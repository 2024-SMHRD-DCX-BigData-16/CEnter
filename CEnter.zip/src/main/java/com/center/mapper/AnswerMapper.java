package com.center.mapper;

import java.util.List;
import com.center.entity.Answer;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AnswerMapper {


    // Ư�� ������ ��� �亯 ��ȸ
    List<Answer> getAnswersByQuestion(int qes_idx);

	public void insertAnswer(Answer answer);

	List<Answer> answerselect(Answer answer);

	List<Answer> getanswerByCategory(Answer answer);

	Answer answercontent(int idx);
}
