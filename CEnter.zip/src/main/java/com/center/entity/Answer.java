package com.center.entity;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@RequiredArgsConstructor
public class Answer {
    private int ans_idx;
    
    @NonNull
    private String mb_id; // ����� ID
    
    @NonNull
    private String ans_category;
    
    @NonNull
    private String ans_item;
    
    @NonNull
    private String ans_problem;
    
    @NonNull
    private String user_answer; // AI�� ������ �亯
    
    @NonNull
    private String ans_yn; // �亯 ���� ���� ('Y' �Ǵ� 'N')
    
    private Timestamp created_at;
    
}
