package com.center.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.center.entity.Answer;
import com.center.entity.Member;
import com.center.entity.Post;
import com.center.entity.Question;
import com.center.mapper.AnswerMapper;
import com.center.mapper.QuestionMapper;
import com.mysql.cj.Session;

@Controller
public class QuestionController {
	
	Map<String, String[]> langlist;
	Map<String, String> cacss;
	
	@Autowired
	private QuestionMapper questionMapper;
	
	@Autowired
	private AnswerMapper answerMapper;

	@RequestMapping("/goQuestionMain")
	public String goQuestionMain() {
		return "QuestionMain"; // main.jsp 페이지 반환
	}
	
	@PostMapping("/api")
    public ResponseEntity<String> receiveData(HttpSession session, @RequestBody Map<String, String> requestData) {
        session.setAttribute("aiContent", requestData.get("result"));
        session.setAttribute("contentyn", requestData.get("ynresult"));
        session.setAttribute("userser", requestData.get("usersresult"));
        return ResponseEntity.ok("데이터 전송 성공");
    }
	@RequestMapping("/questionanswer")
	public String questionanswer(HttpSession session, Question question, Answer answer,
	        @RequestParam(value = "lang", required = false) String lang,
	        @RequestParam(value = "ca", required = false) String ca) {
		Member loginMember = (Member) session.getAttribute("loggedInUser");
		String aiContent = (String) session.getAttribute("aiContent");
		String contentyn = (String) session.getAttribute("contentyn");
		String userser = (String) session.getAttribute("userser");
		
	    String qes_content = aiContent;
	    String qes_category = lang;
	    String qes_item = ca;
	    
	    // Question 객체에 값을 설정
	    question.setQes_content(qes_content);
	    question.setQes_category(qes_category);
	    question.setQes_item(qes_item);

		 answer.setMb_id(loginMember.getMb_id()); 
		 answer.setAns_category(qes_category);
		 answer.setAns_item(qes_item);
		 answer.setAns_problem(qes_content); 
		 answer.setUser_answer(userser);
		 answer.setAns_yn(contentyn);

	    // questionMapper의 questionInsert 메서드 호출
	    questionMapper.insertQuestion(question);
	    answerMapper.insertAnswer(answer);

	    return "questionForm";
	}

	
	
	@RequestMapping("/questionselect")
	public String questionselect(@RequestParam(value = "category", required = false) String category, Model model) {
		List<Question> questionList;
		if(category != null) {
			questionList = questionMapper.getQusetionsByCategory(category);
		}else {
			questionList = questionMapper.questionselect();
		}
		int chunkSize = 6;
        int rows = (int) Math.ceil((double) questionList.size() / chunkSize);
        List<Question[]> chunkedList = new ArrayList<Question[]>();

        for (int i = 0; i < rows; i++) {
            int start = i * chunkSize;
            int end = Math.min(start + chunkSize, questionList.size());
            List<Question> chunk = questionList.subList(start, end);
            chunkedList.add(chunk.toArray(new Question[0])); // 2차원 배열로 변환
        }

        // 결과 확인 (디버깅용)
		model.addAttribute("chunkedList",chunkedList);
		return "QuestionList";
	}
	
	@RequestMapping("/answerselect")
	public String answerselect(Answer answer, HttpSession session, @RequestParam(value = "category", required = false) String category, Model model) {
		List<Answer> answerList;
		Member loginMember = (Member) session.getAttribute("loggedInUser");
		answer.setMb_id(loginMember.getMb_id()); 
		System.out.println("asdf");
		if(category != null) {
			answer.setAns_category(category); 
			answerList = answerMapper.getanswerByCategory(answer);
		}else {
			answerList = answerMapper.answerselect(answer);
		}
		int chunkSize = 6;
        int rows = (int) Math.ceil((double) answerList.size() / chunkSize);
        List<Answer[]> answercheck = new ArrayList<Answer[]>();

        for (int i = 0; i < rows; i++) {
            int start = i * chunkSize;
            int end = Math.min(start + chunkSize, answerList.size());
            List<Answer> chunk = answerList.subList(start, end);
            answercheck.add(chunk.toArray(new Answer[0])); // 2차원 배열로 변환
        }

        // 결과 확인 (디버깅용)
		model.addAttribute("answercheck",answercheck);
		return "QuestionList";
	}
	
	
	
//	@RequestMapping("/questioncontent")
//	   public String questioncontent(@RequestParam int idx, Model model) {
//	      // 내가 선택한 특정 게시글의 모든 정보를 출력!
//	      Question questiondone = questionMapper.questioncontent(idx);
//	      model.addAttribute("questiondone", questiondone);
//	      return "questionRead";
//	}
	
	@RequestMapping("/questioncontent")
	public String questioncontent(@RequestParam int idx, Model model) {
		// 내가 선택한 특정 게시글의 모든 정보를 출력!
		Answer answerdone = answerMapper.answercontent(idx);
		model.addAttribute("answerdone", answerdone);
		return "questionRead";
	}

	// 질문 입력 페이지
	@GetMapping("/goquestionForm")
	public String goquestionForm(@RequestParam(value = "lang", required = false) String lang,
			@RequestParam(value = "ca", required = false) String ca, HttpSession session) {
		langlist = new HashMap<>();
		langlist.put("codingstart",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=coding'>코딩 이란?</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=programming'>프로그래밍 이란?</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=web'>Web 동작 원리</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=language'>대표적인 언어 소개</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=job'>코딩 관련 직종</a></li>", });
          langlist.put("html",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=html 기본구조'>기본구조</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=html 기본태그'>기본태그</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=html 리스트'>리스트</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=html 시맨틱태그'>시맨틱태그</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=html 이미지태그'>이미지태그</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=html 폼태그'>폼태그</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=html 메타데이터'>메타데이터</a></li>" });
          langlist.put("css",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=css 기본선택자'>기본선택자</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=css 텍스트스타일링'>텍스트스타일링</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=css 색상스타일링'>색상스타일링</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=css display속성'>display속성</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=css position속성'>position속성</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=css flex속성'>flex속성</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=css grid속성'>grid속성</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=css 애니메이션'>애니메이션</a></li>" });
          langlist.put("javascript",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=javascript 데이터타입'>데이터타입</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 변수'>변수</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 연산자'>연산자</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 조건문'>조건문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 반복문'>반복문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 제어문'>제어문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 배열'>배열</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 함수'>함수</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 객체'>객체</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 이벤트'>이벤트</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 예외처리'>예외처리</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=javascript 정규표현식'>정규표현식</a></li>" });
          langlist.put("php",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=php 데이터타입'>데이터타입</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 조건문'>조건문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 반복문'>반복문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 배열'>배열</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 함수'>함수</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 내장함수'>내장함수</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 정규표현식'>정규표현식</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php oop'>oop</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 클래스'>클래스</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 쿠키'>쿠키</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 세션'>세션</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=php 예외처리'>예외처리</a></li>" });
          langlist.put("python",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=python 데이터타입'>데이터타입</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python 변수'>변수</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python 연산자'>연산자</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python 조건문'>조건문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python 반복문'>반복문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python 배열'>배열</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python 함수'>함수</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python 객체'>객체</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python math'>math</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python pandas'>pandas</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python numpy'>numpy</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python matplotlib'>matplotlib</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python 웹크롤링'>웹크롤링</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=python flask'>flask</a></li>" });
          
          langlist.put("java",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=java 변수와자료형'>변수와자료형</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 연산자'>연산자</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 형변환'>형변환</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 제어문'>제어문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 배열'>배열</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 메소드'>메소드</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 컬렉션'>컬렉션</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 클래스'>클래스</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 상속'>상속</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 추상클래스'>추상 클래스</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 예외처리'>예외 처리</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=java 멀티스레드'>멀티스레드</a></li>" });
          
          langlist.put("c",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=c언어 변수와자료형'>변수와자료형</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=c언어 상수'>상수</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=c언어 입출력'>입출력</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=c언어 조건문'>조건문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=c언어 반복문'>반복문</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=c언어 배열'>배열</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=c언어 함수'>함수</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=c언어 포인터'>포인터</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=c언어 최단경로'>최단경로</a></li>" });
          
          langlist.put("react",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=react jsx문법'>jsx문법</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=react props'>props</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=react state'>state</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=react 조건부렌더링'>조건부렌더링</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=react 리스트렌더링'>리스트렌더링</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=react useeffect'>useeffect</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=react 라우팅'>라우팅</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=react 비동기처리'>비동기처리</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=react useref'>useref</a></li>" });
          
          langlist.put("jquery",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=jquery 선택자및조작'>선택자및조작</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=jquery 이벤트및애니메이션'>이벤트및애니메이션</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=jquery dom'>dom</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=jquery ajax'>ajax</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=jquery todo리스트'>todo리스트</a></li>" });
          
          langlist.put("mysql",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=mysql 타입'>타입</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=mysql 제약조건'>제약조건</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=mysql dml'>dml</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=mysql dcl'>dcl</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=mysql ddl'>ddl</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=mysql join'>join</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=mysql view'>view</a></li>" });
          
          langlist.put("xml",
                new String[] { "<li><a href='?" + "lang=" + lang + "&" + "ca=xml 문법'>문법</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=xml 문서구조'>문서구조</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=xml dtd'>dtd</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=xml xmlSchema'>xmlSchema</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=xml xpath'>xpath리스트</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=xml xslt'>xslt</a></li>",
                      "<li><a href='/controller/goquestionForm?" + "lang=" + lang + "&" + "ca=xml xml파싱'>xml파싱</a></li>" });

		String[] htmlToics = langlist.get(lang);
		session.setAttribute("topic", htmlToics);

		cacss = new HashMap<>();
		cacss.put("coding", "<h2>코딩(Coding)이란?</h2>\r\n"
	            + "    <div>"
	            + "    <p>\r\n"
	            + "        코딩은 ‘code’와 ‘ing’의 합성어로, 여기서 코드(code)란 프로그램에서 작업을 수행하기 위한 \r\n"
	            + "        명령어 또는 명령어들의 집합을 의미합니다."
	            + "</p>\r\n"
	            + "<p>\r\n"
	            +"즉, 코딩이란 컴퓨터가 이해할 수 있도록  프로그래밍 언어를 사용하여 명령을 작성하는 것을 뜻합니다.\r\n" 
	            + "    </p>\r\n"
	            + "    <h4> 코딩의 사전적 의미</h4>\r\n" + "    <ul>\r\n" + "        <li>어떤 자료나 대상에 기호를 부여하는 작업</li>\r\n"
	            + "        <li>작업 흐름에 따라 프로그램 언어로 명령문을 작성하는 일</li>\r\n" + "        <li>프로그램의 코드를 작성하는 과정</li>\r\n"
	            + "    </ul>\r\n" + "\r\n" + "    <p>\r\n"
	            + "        우리가 대화를 할 때 한국어, 영어, 중국어 등 상황에 맞는 언어를 선택하는 것처럼, \r\n"
	            + "        코딩도 목적에 따라 다양한 프로그래밍 언어를 사용합니다.\r\n"
	            + "    </p>"
	            + "<p>\r\n"
	            + "        대표적인 언어로는 C, Java, Python, PHP 등이 있으며, 각 언어는 특정한 환경과 목적에 따라 사용됩니다.\r\n"
	            + "    </p>"
	            + "    </div>");
	      
	      // 프로그래밍이란?
	      cacss.put("programming",
	            "<h2>2. 프로그래밍 이란?</h2>\r\n" 
	                  + "    <div>"
	                  + "    <p>\r\n" 
	                  + "        프로그래밍이란 ‘수식이나 작업을 컴퓨터에 알맞도록 정리해서 순서를 정하고, \r\n"
	                  + "        컴퓨터 특유의 명령 코드로 변환하는 작업’을 의미합니다.\r\n" + "    </p>\r\n" + "\r\n"
	                  + "    <h4>프로그래밍의 사전적 의미</h4>\r\n" + "    <ul>\r\n"
	                  + "        <li>수식이나 작업을 컴퓨터에 맞도록 정리하는 과정</li>\r\n" + "        <li>작업의 수행 순서를 정하는 과정</li>\r\n"
	                  + "        <li>컴퓨터 특유의 명령 코드로 변환하는 작업</li>\r\n" + "    </ul>\r\n" + "\r\n" + "    <p>\r\n"
	                  + "        앞서 코딩이란 컴퓨터에게 명령을 전달하는 과정이라고 설명했는데요.  \r\n"
	                  + "        간단히 정리하면, <strong>프로그래밍은 코딩을 포함하는 더 큰 개념</strong>이고,  \r\n"
	                  + "        코딩은 프로그래밍의 일부로서 컴퓨터 언어를 사용하여 명령을 입력하는 과정이라고 볼 수 있습니다.\r\n" + "    </p>"
	                  + "    </div>");
	      
	      // 대표적인 언어 소개
	      cacss.put("language", "<h2>대표적인 프로그래밍 언어 소개</h2>\r\n" 
	            + "    <div>"
	            + "    <h3>1. HTML (HyperText Markup Language)</h3>\r\n" + "    <p>\r\n"
	            + "        HTML을 사용하면 텍스트, 이미지, 비디오, 링크, 버튼 등을 배치할 수 있으며, 웹사이트의 구조를 정의할 수 있습니다.\r\n" + "    </p>\r\n"
	            + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n" + "        <li>웹 문서를 만들기 위한 기본 언어</li>\r\n"
	            + "        <li>CSS, JavaScript와 함께 웹 개발의 핵심 기술</li>\r\n"
	            + "        <li>태그 (<code>&lt;h1&gt;</code>, <code>&lt;p&gt;</code>, <code>&lt;img&gt;</code>, <code>&lt;form&gt;</code> 등)를 사용하여 구조 정의</li>\r\n"
	            + "    </ul>\r\n" + "\r\n" + "    <h3>2. CSS (Cascading Style Sheets)</h3>\r\n" + "    <p>\r\n"
	            + "        CSS는 HTML 문서를 디자인하는 스타일링 언어입니다. 색상, 글꼴, 레이아웃을 조정하여 웹사이트를 보다 아름답고 사용자 친화적으로 만들 수 있습니다.\r\n"
	            + "    </p>\r\n" + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n"
	            + "        <li>HTML과 함께 사용하여 웹페이지의 디자인을 담당</li>\r\n"
	            + "        <li>선택자 (<code>.class</code>, <code>#id</code>, <code>element</code>)를 이용한 스타일 지정</li>\r\n"
	            + "        <li>Flexbox, Grid 등 다양한 레이아웃 기능 제공</li>\r\n" + "    </ul>\r\n" + "\r\n"
	            + "    <h3>3. JavaScript (JS)</h3>\r\n" + "    <p>\r\n"
	            + "        JavaScript는 웹페이지에 동적인 기능을 추가하는 프로그래밍 언어입니다. 버튼 클릭, 팝업, 애니메이션, 데이터 처리 등을 구현할 수 있습니다.\r\n"
	            + "    </p>\r\n" + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n"
	            + "        <li>HTML과 CSS와 함께 웹 개발의 핵심 기술</li>\r\n" + "        <li>이벤트 처리, DOM 조작, AJAX 요청 가능</li>\r\n"
	            + "        <li>백엔드(Node.js)에서도 사용 가능</li>\r\n" + "    </ul>\r\n" + "\r\n"
	            + "    <h3>4. PHP (Hypertext Preprocessor)</h3>\r\n" + "    <p>\r\n"
	            + "        PHP는 서버에서 실행되는 웹 프로그래밍 언어입니다. 데이터베이스와 연동하여 로그인, 게시판, 회원가입 등을 구현할 수 있습니다.\r\n"
	            + "    </p>\r\n" + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n"
	            + "        <li>서버에서 실행되는 동적 웹페이지 제작</li>\r\n" + "        <li>MySQL 등과 함께 사용</li>\r\n"
	            + "        <li>다양한 내장 함수 제공</li>\r\n" + "    </ul>\r\n" + "\r\n" + "    <h3>5. Python</h3>\r\n"
	            + "    <p>\r\n"
	            + "        Python은 문법이 간결하고 배우기 쉬운 프로그래밍 언어입니다. 웹 개발, 데이터 분석, 인공지능, 자동화 등 다양한 분야에서 활용됩니다.\r\n"
	            + "    </p>\r\n" + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n" + "        <li>가독성이 높은 코드</li>\r\n"
	            + "        <li>풍부한 라이브러리 제공 (Pandas, NumPy, Flask 등)</li>\r\n"
	            + "        <li>데이터 과학 및 머신러닝에 최적화</li>\r\n" + "    </ul>\r\n" + "\r\n" + "    <h3>6. MySQL</h3>\r\n"
	            + "    <p>\r\n" + "        MySQL은 데이터를 저장하고 관리하는 관계형 데이터베이스 시스템(RDBMS)입니다.\r\n" + "    </p>\r\n"
	            + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n" + "        <li>데이터 저장, 수정, 삭제, 검색 가능</li>\r\n"
	            + "        <li>SQL 언어를 사용하여 데이터 조작</li>\r\n" + "        <li>PHP, Python 등과 함께 사용</li>\r\n"
	            + "    </ul>\r\n" + "\r\n" + "    <h3>7. jQuery</h3>\r\n" + "    <p>\r\n"
	            + "        jQuery는 JavaScript의 기능을 간편하게 사용할 수 있도록 만든 라이브러리입니다. HTML 요소를 쉽게 조작하고, 애니메이션을 추가할 수 있습니다.\r\n"
	            + "    </p>\r\n" + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n" + "        <li>코드가 간결하고 사용하기 쉬움</li>\r\n"
	            + "        <li>AJAX 요청, DOM 조작, 이벤트 처리 가능</li>\r\n" + "    </ul>\r\n" + "\r\n"
	            + "    <h3>8. XML (Extensible Markup Language)</h3>\r\n" + "    <p>\r\n"
	            + "        XML은 데이터를 저장하고 교환하는 마크업 언어입니다.\r\n" + "    </p>\r\n" + "    <h4>🔹 특징</h4>\r\n"
	            + "    <ul>\r\n" + "        <li>데이터를 구조화하여 저장</li>\r\n" + "        <li>JSON과 함께 API에서 많이 사용</li>\r\n"
	            + "    </ul>\r\n" + "\r\n" + "    <h3>9. Java</h3>\r\n" + "    <p>\r\n"
	            + "        Java는 다양한 플랫폼에서 실행되는 객체 지향 프로그래밍 언어입니다. 안드로이드 앱, 웹 애플리케이션, 서버 프로그래밍 등에 사용됩니다.\r\n"
	            + "    </p>\r\n" + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n"
	            + "        <li>플랫폼 독립적 (JVM을 통해 실행)</li>\r\n" + "        <li>객체 지향 프로그래밍 (OOP) 지원</li>\r\n"
	            + "        <li>대규모 시스템 개발에 적합</li>\r\n" + "    </ul>\r\n" + "\r\n" + "    <h3>10. C 언어</h3>\r\n"
	            + "    <p>\r\n" + "        C는 운영체제(OS), 시스템 소프트웨어, 임베디드 시스템 개발 등에 사용되는 프로그래밍 언어입니다.\r\n"
	            + "    </p>\r\n" + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n" + "        <li>빠르고 강력한 성능</li>\r\n"
	            + "        <li>포인터, 메모리 관리 기능 제공</li>\r\n" + "        <li>하드웨어 제어 가능</li>\r\n" + "    </ul>\r\n"
	            + "\r\n" + "    <h3>11. React</h3>\r\n" + "    <p>\r\n"
	            + "        React는 JavaScript 기반의 프론트엔드 라이브러리로, 사용자 인터페이스(UI)를 효율적으로 개발할 수 있습니다.\r\n" + "    </p>\r\n"
	            + "    <h4>🔹 특징</h4>\r\n" + "    <ul>\r\n" + "        <li>컴포넌트 기반 아키텍처</li>\r\n"
	            + "        <li>가상 DOM을 이용한 빠른 렌더링</li>\r\n" + "        <li>상태 관리 기능 (State, Props)</li>\r\n"
	            + "    </ul>"
	            + "    </div>");
	      
	      // web동작원리
	      cacss.put("web", "<div>\r\n" + "<h2>Web 동작 원리</h2>\r\n"
	            + "        <img src=\"resources/images/웹동작원리.png\" alt=\"웹 동작 원리 설명\" style=\"width: 100%; max-width: 600px; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\">\r\n"
	            + "    </div>\r\n" + "\r\n" + "<div>\r\n" + "<ul>\r\n"
	            + "            <li><strong>①②사용자 입력:</strong> 사용자가 웹 브라우저에서 원하는 웹 페이지의 URL을 입력함.</li>\r\n"
	            + "            <li><strong>③DNS 조회:</strong> 입력한 URL의 도메인 네임을 DNS 서버에서 검색함.</li>\r\n"
	            + "            <li><strong>④IP 주소 확인:</strong> DNS 서버에서 해당 도메인의 IP 주소를 찾아 사용자에게 전달함.</li>\r\n"
	            + "            <li><strong>⑤⑥HTTP 요청 생성:</strong> 웹 브라우저가 IP 주소를 기반으로 HTTP 요청 메시지를 생성함.</li>\r\n"
	            + "            <li><strong>⑦데이터 전송:</strong> 요청 메시지는 TCP 프로토콜을 통해 인터넷을 거쳐 해당 서버로 전송됨.</li>\r\n"
	            + "            <li><strong>⑧요청 처리:</strong> 서버는 요청을 분석하고 해당하는 웹 페이지 데이터를 검색함.</li>\r\n"
	            + "            <li><strong>⑨⑩응답 생성:</strong> 검색된 웹 페이지 데이터를 HTTP 응답 메시지로 변환함.</li>\r\n"
	            + "            <li><strong>⑪데이터 전송:</strong> HTTP 응답 메시지가 TCP 프로토콜을 통해 사용자 컴퓨터로 전송됨.</li>\r\n"
	            + "            <li><strong>⑫웹 브라우저 렌더링:</strong> 도착한 데이터를 해석하여 사용자가 볼 수 있는 형태로 화면에 출력함.</li>\r\n"
	            + "        </ul>\r\n" + "    </div>");
	      
	      // 관련직종
	      cacss.put("job", "<h2>코딩 관련 직종</h2>\r\n" + "    <div>"+ "    <h3>1. 프론트엔드 개발자 (Front-End Developer)</h3>\r\n"
	            + "    <p><strong>주요 역할</strong><br>사용자가 직접 보는 화면(UI)과 상호작용하는 웹 애플리케이션을 개발</p>\r\n"
	            + "    <p><strong>주요 업무</strong></p>\r\n" + "    <ul>\r\n"
	            + "        <li>웹사이트 및 웹 애플리케이션 UI 개발</li>\r\n" + "        <li>반응형 웹 디자인 구현</li>\r\n"
	            + "        <li>백엔드와 데이터 연동 (API 호출)</li>\r\n" + "        <li>브라우저 성능 최적화</li>\r\n" + "    </ul>\r\n"
	            + "\r\n" + "    <h3>2. 백엔드 개발자 (Back-End Developer)</h3>\r\n"
	            + "    <p><strong>주요 역할</strong><br>서버, 데이터베이스, 애플리케이션 로직을 개발하여 웹 서비스의 핵심 기능을 구현</p>\r\n"
	            + "    <p><strong>주요 업무</strong></p>\r\n" + "    <ul>\r\n" + "        <li>서버 및 데이터베이스 설계</li>\r\n"
	            + "        <li>사용자 인증 및 보안 관리</li>\r\n" + "        <li>API 개발 및 유지보수</li>\r\n"
	            + "        <li>성능 최적화 및 로드 밸런싱</li>\r\n" + "    </ul>\r\n" + "\r\n"
	            + "    <h3>3. 풀스택 개발자 (Full-Stack Developer)</h3>\r\n"
	            + "    <p><strong>주요 역할</strong><br>프론트엔드와 백엔드를 모두 다룰 수 있는 개발자</p>\r\n"
	            + "    <p><strong>주요 업무</strong></p>\r\n" + "    <ul>\r\n" + "        <li>웹 애플리케이션의 전체 개발 담당</li>\r\n"
	            + "        <li>프론트엔드 & 백엔드 통합</li>\r\n" + "        <li>데이터베이스 및 API 설계</li>\r\n"
	            + "        <li>프로젝트 아키텍처 설계</li>\r\n" + "    </ul>\r\n" + "\r\n"
	            + "    <h3>4. 데이터 엔지니어 (Data Engineer)</h3>\r\n"
	            + "    <p><strong>주요 역할</strong><br>대용량 데이터를 수집, 저장, 처리하는 시스템을 개발</p>\r\n"
	            + "    <p><strong>주요 업무</strong></p>\r\n" + "    <ul>\r\n" + "        <li>데이터 파이프라인 구축 및 유지보수</li>\r\n"
	            + "        <li>실시간 데이터 처리 시스템 개발</li>\r\n" + "        <li>데이터베이스 최적화</li>\r\n" + "    </ul>\r\n"
	            + "\r\n" + "    <h3>5. 데이터 분석가 (Data Analyst)</h3>\r\n"
	            + "    <p><strong>주요 역할</strong><br>데이터를 분석하여 비즈니스 의사 결정을 지원</p>\r\n"
	            + "    <p><strong>주요 업무</strong></p>\r\n" + "    <ul>\r\n" + "        <li>데이터 수집 및 정리</li>\r\n"
	            + "        <li>데이터 시각화 및 리포팅</li>\r\n" + "        <li>고객 행동 분석 및 인사이트 도출</li>\r\n" + "    </ul>\r\n"
	            + "\r\n" + "    <h3>6. 모바일 앱 개발자 (iOS/Android Developer)</h3>\r\n"
	            + "    <p><strong>주요 역할</strong><br>스마트폰 앱(Android, iOS)을 개발</p>\r\n"
	            + "    <p><strong>주요 업무</strong></p>\r\n" + "    <ul>\r\n" + "        <li>모바일 앱 UI/UX 개발</li>\r\n"
	            + "        <li>백엔드 API 연동</li>\r\n" + "        <li>앱 성능 최적화</li>\r\n" + "    </ul>\r\n" + "\r\n"
	            + "    <h3>7. 기타 직업군</h3>\r\n" + "    <ul>\r\n" + "        <li>게임 개발자 : 게임 로직 및 그래픽을 개발</li>\r\n"
	            + "        <li>임베디드 개발자 : 하드웨어와 연동되는 소프트웨어 개발</li>\r\n"
	            + "        <li>QA 엔지니어 : 소프트웨어 테스트 및 품질 보증 담당</li>\r\n"
	            + "        <li>DevOps 엔지니어 : 서버 및 배포 자동화, CI/CD 구축</li>\r\n"
	            + "        <li>보안 엔지니어 : 웹 및 네트워크 보안 담당</li>\r\n"
	            + "        <li>클라우드 엔지니어 : AWS, GCP, Azure 기반 서비스 운영</li>\r\n" + "    </ul>\r\n" + "\r\n"
	            + "    <h4>각 직군마다 요구되는 기술이 다르지만, 프로그래밍을 배운 후에는 이외에도 다양한 분야로 진출할 수 있습니다.</h4>"
	            + "    </div>");

	      // HTML 
	      cacss.put("html 기본구조","<h3>HTML 기본 구조</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            HTML 문서는 기본적으로 <code>&lt;!DOCTYPE html&gt;</code>, <code>&lt;html&gt;</code>,\r\n"
	            + "            <code>&lt;head&gt;</code>, <code>&lt;body&gt;</code> 태그로 구성됩니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>이러한 기본 구조는 웹 브라우저가 페이지를 어떻게 처리할지를 알려주며, 페이지를 렌더링하는 데 중요한 역할을 합니다.</p>\r\n"
	            + "    </div>");
	      cacss.put("html 기본태그","<h3>HTML 기본 태그</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            HTML 문서를 작성할 때 사용되는 기본적인 태그로는 제목을 나타내는 <code>&lt;h1&gt;</code>~<code>&lt;h6&gt;</code>,\r\n"
	            + "            단락을 나타내는 <code>&lt;p&gt;</code>, 링크를 위한 <code>&lt;a&gt;</code>\r\n"
	            + "        </p>\r\n"
	            + "        <p>  \r\n"
	            + "            이미지 삽입을 위한 <code>&lt;img&gt;</code>, 리스트 항목을 위한 <code>&lt;ul&gt;</code>, <code>&lt;ol&gt;</code>, <code>&lt;li&gt;</code> 등이 있습니다.\r\n"
	            + "        </p> \r\n"
	            + "        <p>\r\n"
	            + "            이러한 태그들은 페이지의 구조를 설정하고 내용을 구분하는 데 사용됩니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("html 리스트","<h3>HTML 리스트</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>리스트는 정보를 나열할 때 유용하며, 순서 있는 리스트<code>&lt;ol&gt;</code>와 순서 없는 리스트<code>&lt;ul&gt;</code>로 나뉩니다.</p>\r\n"
	            + "        <p><code>&lt;li&gt;</code> 태그는 리스트 항목을 나타내며, 각 항목을 정의하는 데 사용됩니다.</p>\r\n"
	            + "        <p>순서 있는 리스트는 번호가 매겨지고, 순서 없는 리스트는 점 또는 다른 기호로 구분됩니다.</p>\r\n"
	            + "    </div>");
	      cacss.put("html 시맨틱태그","<h3>HTML 시맨틱 태그</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>HTML 시맨틱 태그는 페이지의 의미를 명확하게 정의하는 태그로, 검색 엔진 최적화(SEO)와 웹 접근성 향상에 도움을 줍니다.</p>\r\n"
	            + "        <p>예를 들어 <code>&lt;header&gt;</code>, <code>&lt;footer&gt;</code>, <code>&lt;article&gt;</code>, <code>&lt;section&gt;</code>, <code>&lt;nav&gt;</code> 등은 페이지의 특정 영역을 구분하며, 콘텐츠의 의미를 명확히 전달합니다.</p>\r\n"
	            + "    </div>");
	      cacss.put("html 이미지태그","<h3>HTML 이미지 태그</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            <code>&lt;img&gt;</code> 태그를 사용하여 웹 페이지에 이미지를 삽입할 수 있습니다. 이미지 파일의 경로를 src 속성에 지정하고, 이미지가 로드되지 않을 경우를 대비해 alt 속성을 사용하여 대체 텍스트를 제공합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("html 폼태그","<h3>HTML 폼 태그</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            HTML 폼은 사용자로부터 데이터를 입력받는 데 사용되며 \r\n"
	            + "        </p>\r\n"
	            + "        <p>   \r\n"
	            + "            <code>&lt;form&gt;</code>, <code>&lt;input&gt;</code>, <code>&lt;textarea&gt;</code>, <code>&lt; button&gt;</code>, <code>&lt;select&gt;</code> 등의 태그를 사용하여 입력 필드를 생성합니다.\r\n"
	            + "            </p> \r\n"
	            + "            <p>\r\n"
	            + "                사용자 입력을 서버로 전송할 수 있도록 action과 method 속성을 설정할 수 있습니다.\r\n"
	            + "            </p>  \r\n"
	            + "    </div>");
	      cacss.put("html 메타데이터","<h3>HTML 메타데이터</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>메타 태그는 페이지에 대한 정보(제목, 설명, 키워드 등)를 제공하며</p>\r\n"
	            + "        \r\n"
	            + "        <p>\r\n"
	            + "        <code>&lt;meta&gt;</code> 태그를 사용하여 문서의 인코딩, 작성자 정보, 검색 엔진 최적화(SEO)와 관련된 정보를 설정합니다.\r\n"
	            + "    </p>\r\n"
	            + "        <p>이 태그는 <head> 태그 안에 위치합니다.</p>\r\n"
	            + "        \r\n"
	            + "        </div> ");
	      
	      // css
	      cacss.put("css 기본선택자","<h3>CSS 기본 선택자</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            CSS에서 요소를 선택하는 기본 방법으로는 태그 선택자, 클래스 선택자, ID 선택자 등이 있습니다\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            태그 선택자는 요소 이름을 기준으로, 클래스 선택자는 클래스 이름을 기준으로, ID 선택자는 고유한 ID를 기준으로 스타일을 적용합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("css 텍스트스타일링","<h3>CSS 텍스트 스타일링</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            CSS를 사용하여 텍스트의 크기, 글꼴, 색상, 간격 등을 스타일링할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            예를 들어 font-size, font-family, color, line-height, letter-spacing 등을 활용하여 텍스트를 꾸밀 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("css 색상스타일링","<h3>CSS 색상 스타일링</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            색상을 적용하는 방법은 color와 background-color 속성을 사용하여 텍스트 및 배경 색상을 설정합니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>   \r\n"
	            + "            색상은 RGB, HEX, HSL 값 등을 사용하여 지정할 수 있습니다.\r\n"
	            + "            </p> \r\n"
	            + "              \r\n"
	            + "    </div>");
	      cacss.put("css display속성","<h3>CSS display 속성</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            display 속성은 요소의 표시 방식을 정의하며\r\n"
	            + "        </p>\r\n"
	            + "        \r\n"
	            + "        <p>\r\n"
	            + "            block, inline, inline-block, flex, grid, none 등이 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "        <p>\r\n"
	            + "            이 속성에 따라 요소가 페이지에서 어떻게 보일지 결정됩니다.\r\n"
	            + "        </p>"
	            + "        </div>");
	      cacss.put("css position속성","<h3>position 속성</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            position 속성은 요소의 위치를 설정하는 데 사용되며\r\n"
	            + "        </p>\r\n"
	            + "        \r\n"
	            + "        <p>\r\n"
	            + "            static, relative, absolute, fixed, sticky 값이 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "        <p>\r\n"
	            + "            이 속성은 요소의 위치를 다른 요소와 어떻게 정렬할지 정의합니다.\r\n"
	            + "\r\n"
	            + "        </p>\r\n"
	            + "        \r\n"
	            + "        </div>");
	      cacss.put("css flex속성","<h3>CSS flex 속성</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            Flexbox는 요소를 일정한 규칙에 따라 배치할 수 있는 방법입니다.\r\n"
	            + "        </p>\r\n"
	            + "        \r\n"
	            + "        <p>\r\n"
	            + "            display: flex를 사용하고, justify-content, align-items, flex-direction 등의 속성으로 레이아웃을 조정할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "        </div>");
	      cacss.put("css grid속성","<h3>CSS grid 속성</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            CSS Grid는 2D 레이아웃을 구성할 때 유용합니다.\r\n"
	            + "        </p>\r\n"
	            + "        \r\n"
	            + "        <p>\r\n"
	            + "            display: grid로 설정하고, grid-template-rows, grid-template-columns, grid-gap 등을 사용하여\r\n"
	            + "    </p>\r\n"
	            + "        <p>\r\n"
	            + "            복잡한 레이아웃을 쉽게 구성할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "        \r\n"
	            + "        </div>");
	      cacss.put("css 애니메이션","<h3>CSS 애니메이션</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            애니메이션을 사용하면 요소에 시간에 따른 변화를 줄 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "        \r\n"
	            + "        <p>\r\n"
	            + "            keyframes 규칙을 정의하여 애니메이션의 동작을 설정하고, animation 속성을 사용하여 애니메이션을 적용합니다.\r\n"
	            + "    </p>\r\n"
	            + "         </div> ");
	      
	      // 2. 프로그래밍 언어
	      // JavaScript
	      cacss.put("javascript 데이터타입","<h3>JS 데이터 타입</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        JavaScript에서 사용되는 주요 데이터 타입에는\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        string, number, boolean, null, undefined, object, symbol, bigint 등이 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        각 타입은 값의 종류를 정의하며, 데이터를 처리하는 데 중요한 역할을 합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 변수","<h3>JS 변수</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        변수는 데이터를 저장하는 용도로 사용되며 var, let, const를 사용하여 변수를 선언할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        let과 const는 var보다 더 최신의 방식으로 변수를 선언합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 연산자","<h3>JS 연산자</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        연산자는 값들을 계산하는 데 사용되며\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        산술 연산자(+, -, *, /), 비교 연산자(==, ===, !=), 논리 연산자(&&, ||, !), 대입 연산자(=, +=, -=) 등이 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 조건문","<h3>JS 조건문</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        조건문은 프로그램 흐름을 제어하는 중요한 구조로\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        if, else if, else, switch 등을 사용하여 조건에 따라 다르게 동작할 수 있도록 합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 반복문","<h3>JS 반복문</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        반복문은 특정 코드를 여러 번 실행할 수 있도록 하며\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        for, while, do...while 등의 반복문을 사용합니다. 배열이나 객체를 순회하는 데 유용합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 제어문","<h3>JS 제어문</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        break, continue, return 등의 제어문은 반복문이나 함수 내에서 프로그램 흐름을 제어하는 데 사용됩니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        이를 통해 코드의 흐름을 효율적으로 관리할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 배열","<h3>JS 배열</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        배열은 여러 값을 하나의 변수에 저장하는 자료형으로, JavaScript에서 중요한 데이터 구조입니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        push(), pop(), shift(), unshift() 등의 메서드를 통해 배열을 조작할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 함수","<h3>JS 함수</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        함수는 재사용 가능한 코드 블록으로, 입력값을 받아서 결과값을 반환합니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        JavaScript에서는 함수 선언식, 함수 표현식, 화살표 함수(arrow function) 등을 사용하여 함수를 정의합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 객체","<h3>JS 객체</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        객체는 키-값 쌍으로 데이터를 저장하는 자료형입니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        각 키는 고유하며, 값은 다양한 데이터 타입일 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        객체를 사용하여 복잡한 데이터를 효율적으로 관리할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 이벤트","<h3>JS 이벤트</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        이벤트는 사용자의 행동(클릭, 마우스오버, 키 입력 등)에 반응하는 방법입니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        addEventListener()를 사용하여 다양한 이벤트를 처리할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 예외처리","<h3>JS 예외처리</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        예외처리는 코드 실행 중 발생할 수 있는 오류를 처리하는 방법입니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            try, catch, finally 블록을 사용하여 오류를 처리하고, 프로그램이 중단되지 않도록 합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("javascript 정규표현식","<h3>JS 정규표현식</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        정규표현식은 문자열을 검색하거나 교체할 때 사용됩니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        패턴을 정의하여 문자열 내에서 원하는 부분을 찾거나 수정할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      
	      // PHP
	      cacss.put("php 데이터타입","<h3>PHP 데이터 타입</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "        PHP에서는 정수, 실수, 문자열, 배열, 객체 등 다양한 데이터 타입을 사용합니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "        변수는 동적 타입을 가지며, 선언 없이 바로 값을 할당할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 조건문","<h3>PHP 조건문</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            PHP에서 조건문은 if, else, elseif 등을 사용하여 주어진 조건에 따라 다른 동작을 수행합니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            switch 문도 조건이 여러 가지일 때 유용하게 사용됩니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 반복문","<h3>PHP 반복문</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            PHP에서 반복문은 for, while, do...while, foreach 등을 사용하여\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            특정 코드를 반복 실행할 수 있게 합니다. 배열 순회 시 foreach가 유용합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 배열","<h3>PHP 배열</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            배열은 여러 값을 저장할 수 있는 데이터 구조로\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            PHP에서는 인덱스 배열과 연관 배열을 사용할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            배열 함수들(array_push(), array_pop(), array_merge())로 배열을 다룰 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 함수","<h3>PHP 함수</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            PHP에서 함수는 특정 작업을 수행하는 코드 블록으로, function 키워드를 사용하여 정의합니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            함수는 인수를 받아서 결과를 반환하거나, 반환하지 않을 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 내장함수","<h3>PHP 내장 함수</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            PHP에는 문자열 처리, 날짜 처리, 배열 조작 등 다양한 작업을 처리할 수 있는 내장 함수들이 많이 제공됩니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            예를 들어, strlen(), array_merge(), date() 등이 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 정규표현식","<h3>PHP 정규 표현식</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            PHP에서는 preg_match(), preg_replace() 등을 사용하여 정규 표현식을 처리할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            이를 통해 문자열을 검색하거나 대체할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php oop","<h3>PHP OOP (객체지향 프로그래밍)</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            PHP는 객체지향 언어로, 클래스와 객체를 사용하여 코드의 재사용성을 높이고, 유지보수성을 향상시킬 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            클래스는 속성과 메서드를 포함하며, 객체는 클래스를 기반으로 인스턴스를 생성합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 클래스","<h3>PHP 클래스</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            클래스는 객체지향 프로그래밍에서 객체를 생성하기 위한 틀을 제공합니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            클래스 내에서는 속성과 메서드를 정의할 수 있으며, 객체는 이를 인스턴스화하여 사용합니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 쿠키","<h3>PHP 쿠키</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            쿠키는 클라이언트에 데이터를 저장하는 방식입니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            PHP에서 setcookie() 함수로 쿠키를 설정하고, $_COOKIE 변수를 통해 쿠키 값을 읽을 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 세션","<h3>PHP 세션</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            세션은 서버에 데이터를 저장하여 사용자의 상태를 유지하는 방법입니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            PHP에서는 session_start()로 세션을 시작하고\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            $_SESSION 배열을 사용하여 데이터를 저장하고 접근할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      cacss.put("php 예외처리","<h3>PHP 예외처리</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            PHP에서 예외처리는 try, catch, throw 키워드를 사용하여 오류를 처리합니다.\r\n"
	            + "        </p>\r\n"
	            + "        <p>\r\n"
	            + "            예외는 프로그램 흐름을 중단시키지 않고, 오류가 발생한 지점을 처리할 수 있게 해줍니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      
	      // Python
	      cacss.put("python 데이터타입","<h3>Python 데이터 타입</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Python에서 사용되는 데이터 타입으로는 int, float, str, list, tuple, dict, set, bool 등이 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        각 데이터 타입은 데이터를 저장하는 방식과 해당 데이터에 적용할 수 있는 연산이 다릅니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python 변수","<h3>Python 변수</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Python에서 변수는 값을 저장하기 위한 이름을 지정하는 방식으로"
	            + "    </p>\r\n"
	            + "    <p>\r\n"
	            + "         변수 선언 시 타입을 명시할 필요 없이 값을 할당하면 자동으로 타입이 결정됩니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python 연산자","<h3>Python 연산자</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Python에서는 산술 연산자(+, -, *, /, //, %), 비교 연산자(==, !=, <, >, <=, >=)\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        논리 연산자(and, or, not), 할당 연산자(=, +=, -=) 등을 제공합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python 조건문","<h3>Python 조건문</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        조건문은 주어진 조건에 따라 다른 실행 경로를 설정하는 구문입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        if, elif, else 키워드를 사용하여 다양한 조건을 처리할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python 반복문","<h3>Python 반복문</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Python에서 반복문은 for와 while로 구성되며\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        리스트나 범위(range())와 같은 이터러블을 순회하거나 조건이 참인 동안 반복 실행할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python 제어문","<h3>Python 제어문</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Python에서 break, continue, return 등의 제어문을 사용하여 반복문이나 함수의 흐름을 제어할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        break는 반복문을 종료시키고, continue는 반복문의 나머지 부분을 건너뛰며, return은 함수에서 값을 반환하고 종료합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python 배열","<h3>Python 배열</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Python에서 배열은 리스트(list)로 구현됩니다. 리스트는 다양한 데이터 타입을 담을 수 있으며\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        append(), remove(), pop() 등의 메서드를 이용하여 요소를 추가하거나 삭제할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python 함수","<h3>Python 함수</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Python에서는 def 키워드를 사용하여 함수를 정의합니다.    \r\n"
	            + "    </p>\r\n"
	            + "    <p>   \r\n"
	            + "        함수는 인자와 반환 값을 가질 수 있으며, lambda 표현식을 이용하여 간단한 익명 함수도 생성할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python 객체","<h3>Python 객체</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Python은 객체지향 언어로 클래스와 객체를 사용하여 데이터를 다룹니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        클래스는 class 키워드로 정의하고, 인스턴스를 생성하여 속성 및 메서드를 사용할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python math","<h3>Python math</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        math 라이브러리는 수학 관련 함수들을 제공합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>   \r\n"
	            + "        예를 들어, sqrt(), sin(), cos(), tan() 등의 함수가 있으며, 숫자 관련 연산을 더 효율적으로 할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python pandas","<h3>Python pandas</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        pandas는 데이터 분석을 위한 라이브러리로, DataFrame과 Series 자료구조를 제공합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        이를 사용하여 표 형식의 데이터를 쉽게 처리하고 분석할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python numpy","<h3>Python numpy</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        numpy는 고성능 수치 계산을 위한 라이브러리입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        배열(ndarray)을 사용하여 대규모 데이터의 처리와 복잡한 수학적 계산을 효율적으로 수행할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python matplotlib","<h3>Python matplotlib</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        matplotlib는 데이터 시각화를 위한 라이브러리로, 다양한 유형의 그래프와 차트를 생성할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        예를 들어, plot(), scatter(), hist() 등의 함수로 데이터를 시각적으로 표현할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python 웹크롤링","<h3>Python 웹크롤링</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        웹크롤링은 웹 페이지에서 데이터를 자동으로 수집하는 작업으로\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        requests와 BeautifulSoup 라이브러리를 사용하여 HTML을 파싱하고 원하는 데이터를 추출할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("python flask","<h3>Python flask</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Flask는 Python을 사용하여 웹 애플리케이션을 구축할 수 있는 경량화된 웹 프레임워크입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        이를 이용해 간단한 웹 서버를 만들고 REST API를 구축하는 것이 가능합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      
	      // java
	      cacss.put("java 변수와자료형","<h3>Java 변수와 자료형</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Java에서는 데이터를 저장하기 위해 기본 자료형과 객체 자료형을 사용합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        기본 자료형으로는 int, float, boolean, char 등이 있으며, 객체 자료형은 String, Array, Object 등이 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        변수는 값을 저장하는 메모리 공간을 나타내며, 타입에 따라 메모리 크기가 달라집니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 연산자","<h3>Java 연산자</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Java에서 연산자는 값을 처리하는 데 사용되는 기호입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        산술 연산자(+, -, *, /)는 숫자 계산에 사용되며, 비교 연산자(==, !=, >, <)는 값을 비교하고, 논리 연산자(&&, ||, !)는 조건을 결합하는 데 사용됩니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        또한 대입 연산자(=, +=, -=)는 변수에 값을 할당하는 데 사용됩니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 형변환","<h3>Java 형변환</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        형변환은 데이터 타입을 변환하는 과정으로, Java에서는 자동 형변환(묵시적 형변환)과 수동 형변환(명시적 형변환) 두 가지 방식이 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        예를 들어, int 타입을 double로 변환할 때는 자동 형변환이 이루어지며, 그 반대의 경우에는 명시적 형변환이 필요합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 제어문","<h3>Java 제어문</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        제어문은 프로그램의 흐름을 제어하는 구문입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        if, else, switch 문을 사용하여 조건에 따른 실행을 분기할 수 있으며, while, for 문을 사용하여 반복을 수행할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        break와 continue를 사용하여 반복문을 제어할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 배열","<h3>Java 배열</h3>\r\n"
		            + "<div>\r\n"
		            + "    <p>\r\n"
		            + "        배열은 동일한 데이터 타입의 여러 값을 저장하는 데 사용됩니다.\r\n"
		            + "    </p>\r\n"
		            + "    <p>    \r\n"
		            + "        Java에서 배열은 크기가 고정되며, new 키워드를 사용하여 배열을 생성하고 인덱스를 통해 요소에 접근할 수 있습니다.\r\n"
		            + "    </p>\r\n"
		            + "    <p>    \r\n"
		            + "        배열은 데이터를 효율적으로 처리할 수 있게 해줍니다.\r\n"
		            + "    </p>\r\n"
		            + "</div>");
	      cacss.put("java 메소드","<h3>Java 메소드</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        메소드는 특정 작업을 수행하는 코드 블록입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        메소드는 void로 정의되거나 값을 반환할 수 있으며, 인자를 통해 외부 데이터를 입력받고, 그 결과를 반환할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        메소드는 객체 지향 프로그래밍에서 코드 재사용성과 유지보수를 돕습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 컬렉션","<h3>Java 컬렉션</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        컬렉션은 여러 데이터를 효율적으로 저장하고 관리할 수 있는 데이터 구조입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        Java의 컬렉션 프레임워크에는 List, Set, Map 등이 있으며, 각 컬렉션은 특정 용도에 맞게 데이터를 저장하고 검색할 수 있는 다양한 방법을 제공합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 클래스","<h3>Java 클래스</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        클래스는 객체를 생성하기 위한 설계도입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        Java에서는 class 키워드를 사용하여 클래스를 정의하고, 클래스 내에 변수와 메소드를 정의할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        객체는 클래스를 기반으로 생성된 인스턴스입니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 상속","<h3>Java 상속</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        상속은 기존 클래스를 확장하여 새로운 클래스를 만드는 기능입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        extends 키워드를 사용하여 부모 클래스의 속성과 메소드를 자식 클래스가 물려받을 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        이를 통해 코드의 재사용성과 유지보수를 개선할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 추상클래스","<h3>Java 추상 클래스</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        추상 클래스는 직접 인스턴스를 생성할 수 없는 클래스입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        추상 메소드를 포함하고 있으며, 이 메소드는 자식 클래스에서 구현해야 합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        추상 클래스를 사용하여 공통적인 속성과 메소드를 정의하고, 세부 구현은 자식 클래스에서 담당하게 할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 예외처리","<h3>Java 예외 처리</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        예외 처리란 프로그램 실행 중 발생할 수 있는 오류를 처리하는 방법입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        Java에서는 try, catch, finally 블록을 사용하여 예외를 처리하고, 예외 발생 시 프로그램이 정상적으로 종료되지 않도록 합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        예외 처리는 프로그램의 안정성을 높이는 데 중요합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("java 멀티스레드","<h3>Java 멀티스레드</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        멀티스레드는 하나의 프로그램에서 여러 작업을 동시에 처리하는 기술입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        Java에서는 Thread 클래스를 사용하거나, Runnable 인터페이스를 구현하여 멀티스레딩을 구현할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        이를 통해 CPU 자원을 효율적으로 활용하고, 사용자 경험을 향상시킬 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      
	      // C언어
	      cacss.put("c언어 변수와자료형","<h3>C언어 변수와 자료형</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        C에서 변수는 데이터를 저장하는 공간을 제공합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>\r\n"
	            + "        기본적인 자료형으로는 int, float, double, char, bool 등이 있으며, 이를 사용하여 다양한 종류의 데이터를 처리합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        각 자료형은 고유한 메모리 크기와 범위를 가집니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("c언어 상수","<h3>C언어 상수</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        C에서 상수는 const 키워드를 사용하여 값을 변경할 수 없는 변수로 정의됩니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        상수는 프로그램 실행 중에 변하지 않는 값이 필요할 때 사용됩니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("c언어 입출력","<h3>C언어 입출력</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        C에서는 printf와 scanf 함수를 사용하여 입출력을 처리합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        printf는 출력 함수이고, scanf는 사용자로부터 입력을 받는 함수입니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("c언어 조건문","<h3>C언어 조건문</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        C에서 조건문은 if, else if, else, switch를 사용하여 다양한 조건을 평가하고 분기 처리할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        조건에 따라 프로그램의 흐름을 제어할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("c언어 반복문","<h3>C언어 반복문</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        C에서는 for, while, do-while 구문을 사용하여 반복 작업을 처리합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        for는 반복 횟수가 정해져 있을 때, while은 조건에 따라 반복을 진행할 때 사용됩니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("c언어 배열","<h3>C언어 배열</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        배열은 동일한 자료형의 데이터를 연속적으로 저장하는 자료구조입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        C에서는 배열의 크기를 선언할 때 고정해야 하며, 배열은 0부터 시작하는 인덱스를 가집니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("c언어 함수","<h3>C언어 함수</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        C에서 함수는 특정 작업을 수행하는 코드 블록으로, return 값을 가지거나 void로 반환값이 없을 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        함수를 사용하여 코드의 재사용성을 높이고 프로그램을 구조화할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("c언어 포인터","<h3>C언어 포인터</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        포인터는 변수의 메모리 주소를 저장하는 변수입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        포인터를 사용하면 간접적으로 변수에 접근할 수 있으며, 메모리 관리와 동적 메모리 할당에서 중요한 역할을 합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("c언어 최단경로","<h3>C언어 최단경로</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        C에서는 그래프 이론을 적용하여 최단경로를 찾을 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        다익스트라 알고리즘, 벨만-포드 알고리즘 등이 사용되어 최단경로 문제를 해결합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      
	      // 3. 프론트엔드 프레임워크 & 라이브러리
	      // react
	      cacss.put("react jsx문법","<h3>React JSX 문법</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        JSX(JavaScript XML)는 JavaScript 안에서 HTML과 같은 문법을 사용할 수 있도록 하는 문법입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        JSX는 React 컴포넌트를 정의할 때 HTML 요소와 JavaScript 코드를 결합하여 작성할 수 있게 합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("react props","<h3>React Props</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        Props는 부모 컴포넌트에서 자식 컴포넌트로 데이터를 전달하는 방법입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        Props는 읽기 전용이며, 자식 컴포넌트는 이를 수정할 수 없습니다. props를 사용하여 컴포넌트 간의 데이터 흐름을 제어합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("react state","<h3>React State</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        State는 컴포넌트 내에서 동적인 데이터를 관리하는 방법입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        useState 훅을 사용하여 컴포넌트의 상태를 정의하고, 상태 변경 시 UI를 재렌더링할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("react 조건부렌더링","<h3>React 조건부 렌더링</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        React에서는 조건에 따라 다르게 렌더링할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        if 문, 삼항 연산자(? :), && 연산자 등을 사용하여 조건에 따라 다양한 UI를 동적으로 렌더링할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("react 리스트렌더링","<h3>React 리스트 렌더링</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        React에서는 배열이나 리스트를 동적으로 렌더링할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        map() 메서드를 사용하여 배열의 각 요소를 컴포넌트로 변환하여 렌더링할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("react useeffect","<h3>React useEffect</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        useEffect는 컴포넌트가 렌더링된 후 특정 작업을 수행하도록 설정할 수 있는 React 훅입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        데이터 페칭, DOM 업데이트, 구독 설정 등 다양한 side effect를 처리할 때 사용됩니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("react 라우팅","<h3>React 라우팅</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        React에서는 react-router-dom 라이브러리를 사용하여 애플리케이션 내에서 페이지 간 이동을 구현할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        Route, Switch, Link 등의 컴포넌트를 사용하여 클라이언트 사이드 라우팅을 처리합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("react 비동기처리","<h3>React 비동기 처리</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        React에서는 비동기 처리를 위해 async/await 구문을 사용하거나, fetch API 또는 axios 라이브러리를 이용하여\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        서버와 데이터를 주고받습니다. 이를 통해 비동기 작업을 효율적으로 처리할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("react useref","<h3>React useRef</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        useRef는 React 훅으로, DOM 요소나 변수에 대한 참조를 유지하고 직접 접근할 수 있도록 합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        useRef는 컴포넌트가 리렌더링될 때 값을 유지할 수 있는 방법을 제공합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      
	      // jQuery
	      cacss.put("jquery 선택자및조작","<h3>jQuery 선택자 및 조작</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        jQuery는 HTML 요소를 선택하고 조작하는 데 사용됩니다.$(selector) 구문을 사용하여 요소를 선택하고\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        addClass(), removeClass(), text(), html() 등을 이용해 해당 요소의 스타일이나 내용을 변경할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("jquery 이벤트및애니메이션","<h3>jQuery 이벤트 및 애니메이션</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        jQuery는 다양한 이벤트(click, hover, keypress 등)를 쉽게 처리할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        또한, fadeIn(), fadeOut(), slideUp(), slideDown() 등의 애니메이션 메서드를 사용하여 페이지 요소에 동적인 효과를 줄 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("jquery dom","<h3>jQuery DOM</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        jQuery는 DOM(Document Object Model)을 쉽게 조작할 수 있도록 돕습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        append(), prepend(), remove(), clone() 등을 사용하여 DOM 요소를 추가하거나 삭제할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("jquery ajax","<h3>jQuery AJAX</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        AJAX는 비동기적으로 서버와 데이터를 주고받을 수 있는 기술로\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        jQuery의 $.ajax()나 $.get(), $.post()를 사용하여 페이지를 새로 고침 없이 데이터를 전송하거나 받을 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("jquery todo리스트","<h3>jQuery TODO리스트</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        jQuery를 활용하여 동적인 TODO 리스트를 만들 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        사용자가 할 일을 추가하고, 완료된 작업을 표시하며, 리스트에서 항목을 삭제하는 기능을 구현할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      
	      // 4. 데이터베이스
	      // MySQL
	      cacss.put("mysql 타입","<h3>MySQL 타입</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        MySQL에서 데이터는 다양한 타입으로 저장됩니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        기본적인 데이터 타입으로는 INT, VARCHAR, TEXT, DATE, FLOAT, DECIMAL 등이 있으며\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        데이터의 성격에 맞는 타입을 선택하여 효율적으로 저장할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("mysql 제약조건","<h3>MySQL 제약조건</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        제약조건은 데이터의 무결성을 유지하기 위해 사용됩니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        예를 들어, NOT NULL, UNIQUE, PRIMARY KEY, FOREIGN KEY 등은 데이터가 올바르게 입력되고 관리되도록 합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("mysql dml","<h3>MySQL DML (데이터 조작 언어)</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        DML은 데이터를 조회, 삽입, 수정, 삭제하는 SQL 명령어를 포함합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        대표적인 명령어로는 SELECT, INSERT, UPDATE, DELETE가 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("mysql dcl","<h3>MySQL DCL (데이터 제어 언어)</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        DCL은 데이터베이스의 접근 제어를 다루는 SQL 명령어로, GRANT와 REVOKE가 대표적입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        이 명령어들은 사용자의 권한을 부여하거나 취소하는 데 사용됩니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("mysql ddl","<h3>MySQL DDL (데이터 정의 언어)</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        DDL은 데이터베이스의 구조를 정의하는 SQL 명령어로, CREATE, ALTER, DROP, TRUNCATE 등이 포함됩니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        이를 통해 테이블, 인덱스, 뷰 등을 정의하거나 수정할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("mysql join","<h3>MySQL JOIN</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        JOIN은 두 개 이상의 테이블에서 관련된 데이터를 결합하여 조회하는 명령어입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        INNER JOIN, LEFT JOIN, RIGHT JOIN, FULL JOIN 등 여러 종류가 있으며, 각기 다른 방식으로 데이터를 결합합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("mysql view","<h3>MySQL VIEW</h3>\r\n"
	            + "    <div>\r\n"
	            + "        <p>\r\n"
	            + "            VIEW는 하나 이상의 테이블에서 데이터를 조회한 결과를 가상의 테이블로 정의할 수 있게 해주는 SQL 기능입니다.\r\n"
	            + "        </p>   \r\n"
	            + "        <p> \r\n"
	            + "            이를 통해 복잡한 쿼리의 결과를 재사용하거나 보안을 강화할 수 있습니다.\r\n"
	            + "        </p>\r\n"
	            + "    </div>");
	      
	      // 5. XML관련
	      cacss.put("xml xml","<h3>XML 문법</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        XML은 데이터를 저장하고 전송하는 데 사용되는 마크업 언어로\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        태그(<code>&lt;tag&gt;</code>)로 데이터를 구분하며, 루트 엘리먼트가 있어야 합니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("xml 문서구조","<h3>XML 문서 구조</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        XML 문서는 계층 구조로 데이터를 저장합니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        각 태그는 부모와 자식 관계를 가지며, 데이터를 중첩하여 저장할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("xml dtd","<h3>DTD</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        DTD(Document Type Definition)는 XML 문서의 구조를 정의하는 규칙입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        이를 통해 문서가 규정된 형식에 맞는지 검증할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("xml schema","<h3>Schema</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        XML Schema는 XML 문서의 구조를 정의하는 더 강력한 방법으로\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        데이터의 타입, 요소의 순서, 필수 여부 등을 세부적으로 지정할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("xml xpath","<h3>XPath</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        XPath는 XML 문서 내에서 특정 요소를 찾는 경로 언어입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        예를 들어, /person/name과 같은 경로로 데이터를 검색할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("xml xslt","<h3>XSLT</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        XSLT는 XML 문서를 다른 형식으로 변환하는 기술입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        이를 사용하여 XML 데이터를 HTML, PDF, 텍스트 등 다른 형식으로 변환할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");
	      cacss.put("xml xml파싱","<h3>XML 파싱</h3>\r\n"
	            + "<div>\r\n"
	            + "    <p>\r\n"
	            + "        XML 파싱은 XML 문서를 읽어들여 사용자가 원하는 형식으로 변환하는 작업입니다.\r\n"
	            + "    </p>\r\n"
	            + "    <p>    \r\n"
	            + "        Python에서는 xml.etree.ElementTree 모듈을 사용하거나, lxml 라이브러리를 이용해 XML을 파싱할 수 있습니다.\r\n"
	            + "    </p>\r\n"
	            + "</div>");

		String caToics = cacss.get(ca);
		session.setAttribute("catopics", caToics);

		return "questionForm"; // 질문 입력 페이지로 이동
	}

	
	

}
