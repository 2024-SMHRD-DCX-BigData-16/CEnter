package com.center.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.center.entity.Post;
import com.center.mapper.PostMapper;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@Controller
public class PostController {
	
	@Autowired
	PostMapper postmapper;
	
	@RequestMapping("/postwrite")
    public String main() {
        return "PostWrite"; // main.jsp ������ ��ȯ
    }
	@PostMapping("/postinsert")
	public String postinsert(Post post, HttpServletRequest request) {
		MultipartRequest multi = null;

		try {
			// 1. ��û��ü(request)
			// 2. ������ ������ ������ ���(String)
			String savePath = request.getRealPath("resources/upload");
			System.out.println(savePath);
			// 3. ��� �뷮 ũ��(int)
			int maxSize = 1024 * 1024 * 10;// 10MB
			// 4. ���� �̸��� ���ڵ� ���(String)
			String encoding = "UTF-8";
			// 5. �ߺ��̸� ����(DefaultFileRenamePolicy)
			DefaultFileRenamePolicy dfrp = new DefaultFileRenamePolicy();

			multi = new MultipartRequest(request, savePath, maxSize, encoding, dfrp);

			String post_title = multi.getParameter("post_title");
			String mb_id = multi.getParameter("mb_id");
			String post_category = multi.getParameter("post_category");
			String post_file = multi.getFilesystemName("post_file");
			String post_content = multi.getParameter("post_content");

	        if (post_file == null) {
	            post_file = ""; // Ȥ�� null�� ����ϴ� ��� �״�� ��
	        }
			// DB�� �־��ֱ� ���ؼ� �����ֱ�! -> Mybatis

			post = new Post(post_category, post_title, post_content, post_file, mb_id);
			System.out.println(post);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int result = postmapper.insertPost(post);

		if (result > 0) {
			System.out.println("�Խñ� ���ε� �Ϸ�!");
		} else {
			System.out.println("�Խñ� ���ε� ����!");
		}

		return "redirect:/postselect";
	}
	
	@RequestMapping("/postselect")
	public String postselect(@RequestParam(value = "category", required = false) String category, Model model) {
		List<Post> postList;
		if(category != null) {
			postList = postmapper.getPostsByCategory(category);
		}else {
			postList = postmapper.postselect();
		}
		int chunkSize = 6;
        int rows = (int) Math.ceil((double) postList.size() / chunkSize);
        List<Post[]> chunkedList = new ArrayList<Post[]>();

        for (int i = 0; i < rows; i++) {
            int start = i * chunkSize;
            int end = Math.min(start + chunkSize, postList.size());
            List<Post> chunk = postList.subList(start, end);
            chunkedList.add(chunk.toArray(new Post[0])); // 2���� �迭�� ��ȯ
        }

        // ��� Ȯ�� (������)
		model.addAttribute("chunkedList",chunkedList);
		return "PostMain";
	}
	
	@RequestMapping("/postcontent")
	   public String postcontent(@RequestParam int idx, Model model) {
	      // ���� ������ Ư�� �Խñ��� ��� ������ ���!
	      postmapper.updateViewCount(idx);
	      Post postdone = postmapper.postcontent(idx);
	      model.addAttribute("postdone", postdone);
	      return "PostRead";
	   }


}
